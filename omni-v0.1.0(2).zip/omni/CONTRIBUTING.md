# Contributing to OMNI

Thanks for helping improve OMNI. The project prioritizes reproducible changes, clear permissions, verifiable execution, and honest capability reporting.

## Local setup

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\Activate.ps1
python -m pip install -r requirements-dev.txt
python -m compileall -q app run.py
node --check app/static/app.js
python -m pytest -q
```

No Node dependency install is needed for the current static browser UI.

## Engineering expectations

- Keep provider, storage, task engine and tool execution boundaries separate.
- Add tests for both success and failure paths, especially invalid input, permission denial, cancellation/approval and persistence.
- Never execute arbitrary model-generated shell commands in the host process.
- Keep network access disabled unless the user enables it; explicitly describe domains/permissions used by new tools.
- Do not place API tokens or sample secrets in tests, docs, logs or committed configuration.
- Use scoped filesystem paths, bounded payloads/timeouts, and explicit approval for destructive or externally consequential effects.
- Distinguish a planned action, a dispatched action, a tool result and a verified outcome.
- Label demo/mock outputs as simulated and do not claim tests or integrations ran unless they did.
- Update the architecture/security docs and changelog whenever permissions or external behavior change.

## Pull request checklist

1. Explain the user-visible behavior and why the change belongs in OMNI's core or a plugin.
2. Add/change tests and run the suite.
3. State environment-dependent checks that could not be run.
4. Document newly required settings, dependencies, data migrations, permissions and recovery steps.
5. Keep the patch focused and avoid committing local databases, `.env`, generated workspace files or model weights.

## Extension guidance

The current Python plugin loader is disabled by default and runs trusted modules with the server's process permissions; do not use it to run third-party uploads. For a new core tool, declare the schema and permission metadata in `app/tools/registry.py`, implement a constrained executor, and add a failure-focused test. See `docs/PLUGIN_DEVELOPMENT.md`.
