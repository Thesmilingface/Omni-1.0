# Changelog

## 0.1.0 — Initial functional foundation

- Added FastAPI API with local-first launch defaults and optional bearer token auth.
- Added SQLite persistence for conversations, messages, settings, profiles, projects, memories, tasks, and tool audit records.
- Added deterministic offline demo provider and OpenAI-compatible Chat Completions/SSE adapter.
- Added a responsive static browser UI with streaming chat, history, model configuration, projects, memory, profiles, tools and task views.
- Added restricted arithmetic, scoped workspace tools, public URL text retrieval, optional Tavily search, input validation, tool allowlisting, approval gates, and a bounded task runner.
- Added explicitly opt-in administrator-trusted Python plugin loading.
- Added tests, architecture/API/plugin/security docs, MIT license, dependency inventory, Docker Compose and CI workflow.
- Documented incomplete integrations and security limitations.
