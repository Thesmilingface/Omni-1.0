# OMNI — Open Modular Neural Intelligence

OMNI is an open-source, local-first AI workspace with persistent chat, a configurable model adapter, a permission-aware tool registry, and a bounded task runner. It is designed to be extended without pretending that every planned integration is already available.

**Release status: v0.1.0 — functional foundation / early prototype.** It is usable locally, but it is not yet the full autonomous platform described in the master specification. See [implemented capabilities](#implemented-capabilities) and [known limitations](#known-limitations).

## Quick start

Requirements: Python 3.11+ (Python 3.12 recommended). No Node.js build is required for the browser UI.

```bash
git clone <your-fork-url> omni
cd omni
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run.py
```

Open **http://127.0.0.1:8000**. On first launch, OMNI creates a SQLite database under `./data` and a scoped file workspace under `./workspace`. Use the app in offline demo mode first; that provider is a deterministic stub, **not a language model**.

To stop the server, press `Ctrl+C`. Persistent conversations, settings, profiles, memories, projects, tasks, and audit records remain in the database.

### Connect a real model

OMNI supports OpenAI-compatible Chat Completions endpoints, including compatible local inference servers such as Ollama. Install and start the model server separately; OMNI does not download model weights for you.

1. Open **Settings → Model provider**.
2. Select **OpenAI-compatible endpoint**.
3. Set the endpoint URL (for example, `http://127.0.0.1:11434/v1` for a local Ollama setup) and the exact model identifier installed on that server.
4. If the endpoint requires a key, set `OMNI_API_KEY` or `OPENAI_API_KEY` in the server environment, then restart OMNI.
5. Open **Models → Check connection** to verify the endpoint's model-list route. Some compatible servers do not expose that route; chat requests may still work.

The browser never accepts or returns the secret itself. A model identifier in Settings is configuration, not proof the model exists or has the capabilities implied by its name.

### Environment configuration

Copy `.env.example` to `.env` and edit it. `python run.py` loads this simple dotenv-style file without a separate dependency. Environment variables already set by the shell take precedence. Do not commit `.env`.

| Variable | Purpose | Default |
|---|---|---|
| `OMNI_HOST` | Bind address | `127.0.0.1` |
| `OMNI_PORT` | HTTP port | `8000` |
| `OMNI_DATA_DIR` | SQLite directory | `./data` |
| `OMNI_DB_PATH` | Optional exact SQLite path | derived from data directory |
| `OMNI_WORKSPACE_DIR` | Filesystem boundary for workspace tools | `./workspace` |
| `OMNI_ACCESS_TOKEN` | Optional single-instance Bearer auth token | unset for localhost use |
| `OMNI_API_KEY` / `OPENAI_API_KEY` | Compatible model key, server-side only | unset |
| `OMNI_TAVILY_API_KEY` | Optional web-search credential | unset |
| `OMNI_TRUST_PYTHON_PLUGINS` | Enable reviewed Python tool plugins | `false` |
| `OMNI_PLUGIN_DIR` | Python plugin directory | `./plugins` |

If you set `OMNI_HOST` to a non-local address, `run.py` refuses to start without `OMNI_ACCESS_TOKEN`. Use a long, random token. The authentication model is single-token/single-instance, not multi-user identity management. Keep OMNI behind a trusted network boundary and HTTPS reverse proxy for remote use.

### Docker Compose

1. Copy `.env.example` to `.env`.
2. Set `OMNI_ACCESS_TOKEN` to a long random token. Never use the example value or an empty token.
3. Run `docker compose up --build`.
4. Open `http://127.0.0.1:8000` and enter the token when prompted.

Compose maps the port to localhost only and uses named volumes for database/workspace persistence. It enables `no-new-privileges`. The container does not by itself isolate configured Python plugins or arbitrary network access at the OS level.

## Implemented capabilities

- **Chat and persistence:** message streaming endpoint, conversation history, deletion, selected conversation loading, local SQLite storage.
- **Model adapters:** clearly labeled deterministic offline demo; configurable OpenAI-compatible chat completion and SSE streaming; compatible `/models` probe.
- **Profiles:** seeded General, Research, Developer, Analyst, Creative, and Automation profiles; editable/creatable profiles with instructions, provider/model override, temperature, tool allowlist, and memory scope.
- **Task execution:** persistent task records, analyzed/planned/executing/verifying states, bounded time budget and retry count, checkpoints, cancellation requests, terminal/partial states, step verification, approval gate and resume for file writes.
- **Tools:** restricted arithmetic evaluator; scoped workspace list/read/write; public HTTP(S) text fetch with network permission and private/reserved IP checks; optional Tavily search adapter.
- **Permissions/audit:** global tool allowlist, network disabled by default, file write confirmation, recent tool-run audit log, explicit approval state for agent tasks.
- **Memory and projects:** create, search, edit, delete explicit memory records; global/project-like scopes; projects stored locally.
- **Extensions:** optional Python module plugin contract. Disabled by default and limited to administrator-trusted modules.
- **UI:** responsive browser interface, dark/light themes, conversation history, streaming messages, tool form and output, task queue, approval and cancel controls, profiles, settings, projects and memory CRUD.
- **Documentation and checks:** REST/OpenAPI docs, architecture/security docs, developer guide, unit/API tests, syntax checks, CI workflow, Docker scaffolding.

## Agent behavior: what “execution” means in this release

The first task planner is intentionally **deterministic and rules-based**. It recognizes arithmetic, URL retrieval, web searches, workspace file operations, and a small set of combined workflows. It does not let an LLM emit arbitrary tool calls or shell commands. Unsupported objectives end as `PARTIALLY_COMPLETED` with a specific limitation rather than falsely claiming completion. The calculator and workspace writer have result verification; fetch/search have basic response/result checks.

The chat provider currently does not perform autonomous model-directed tool calling. Use **Agent workspace** or **Tools & integrations** to invoke the implemented tools. The file writer waits for an explicit approval before creating/replacing the target file.

## Tests and development

```bash
python -m pip install -r requirements-dev.txt
python -m compileall -q app run.py
node --check app/static/app.js
python -m pytest -q
```

API reference: when running locally, open `/docs` for Swagger UI or `/redoc` for the generated API reference. `/api/openapi.json` is also provided; if an access token is enabled, it is protected like the other `/api` routes.

See:
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)
- [`docs/API.md`](docs/API.md)
- [`docs/PLUGIN_DEVELOPMENT.md`](docs/PLUGIN_DEVELOPMENT.md)
- [`docs/SECURITY.md`](docs/SECURITY.md)
- [`docs/THIRD_PARTY_NOTICES.md`](docs/THIRD_PARTY_NOTICES.md)
- [`CONTRIBUTING.md`](CONTRIBUTING.md)
- [`CHANGELOG.md`](CHANGELOG.md)

## Known limitations

- No React/Vite frontend yet. The first release uses a small dependency-free static UI served by FastAPI to minimize installation steps and external browser requests.
- No Hugging Face Transformers or llama.cpp bindings are bundled; use a compatible inference server or develop an adapter.
- No multi-role model router (reasoning/coding/research models concurrently), vision, audio, image generation, or video model workflow.
- No dynamic web browser/desktop control, shell execution, Git automation, calendar/email sender, PostgreSQL backend, vector database, semantic memory retrieval, conversation branching, schedule runner, or user account management.
- Memory uses bounded recent records by configured scope; there is no embedding index or automatic fact verification.
- Plugin loading imports trusted Python code into the application process. It is **not sandboxed** and should only be enabled for code reviewed by the instance administrator.
- Network tools are off by default. The URL fetcher checks DNS results for global IPs and blocks redirects/private destinations, but this is not a complete network sandbox and does not eliminate all DNS-rebinding or infrastructure risks.
- Task planning is a deterministic heuristic, not general-purpose autonomous reasoning. Startup resumes persisted checkpoints for built-in tools. Since a filesystem side effect and its SQLite result record cannot be committed atomically, a crash at that boundary may repeat a workspace overwrite; interrupted plugin steps are marked partially complete and are not replayed automatically.
- The access token is simple single-instance bearer authentication. There is no per-user data isolation; do not expose the service publicly without adding authentication, TLS, and deployment hardening.

## License

OMNI's original code is released under the MIT License. Runtime dependencies retain their own upstream licenses; see the third-party notice and inventory. Model weights, inference servers, plugins, and endpoint terms are separate from the OMNI code license.
