# OMNI HTTP API

Base URL for the default local instance: `http://127.0.0.1:8000`. JSON API routes are under `/api`. When `OMNI_ACCESS_TOKEN` is set, send `Authorization: Bearer <token>` on `/api/*` requests, except `/api/health` and `/api/auth/status`.

## Health and settings

- `GET /api/health` — process-level health and active provider mode; it does not verify a remote model connection.
- `GET /api/auth/status` — whether token auth is configured.
- `GET /api/config` — current settings with boolean secret-presence indicators, never secret values.
- `PUT /api/config` — update validated settings such as `provider`, `base_url`, `model`, `temperature`, `max_tokens`, `system_instructions`, `network_enabled`, `enabled_tools`, `task_retry_limit`, `task_timeout_seconds`, `default_profile`, and `theme`.
- `GET /api/models` — configured endpoint model-list probe where supported.
- `GET /api/plugins` — plugin loader status. Python plugins need explicit trusted-code opt-in.

Example:

```bash
curl http://127.0.0.1:8000/api/config
curl -X PUT http://127.0.0.1:8000/api/config \
  -H 'Content-Type: application/json' \
  -d '{"provider":"openai_compatible","base_url":"http://127.0.0.1:11434/v1","model":"qwen2.5:3b"}'
```

## Chat and conversations

- `POST /api/chat` — full-response chat call. Body: `{ "message": "...", "conversation_id": "optional-id", "profile_id": "optional-id" }`.
- `POST /api/chat/stream` — Server-Sent Events with `delta`, `done`, or `error` JSON events. The user message is persisted before generation; the assistant response is persisted after a successful stream.
- `GET /api/conversations` — recent conversation records.
- `POST /api/conversations` — create an empty conversation.
- `GET /api/conversations/{id}` — conversation and messages.
- `DELETE /api/conversations/{id}` — delete a conversation and its messages.

## Tools and tasks

- `GET /api/tools` — tool metadata, input schema, permission labels, enabled/connected status.
- `POST /api/tools/{name}/execute` — execute one registered enabled tool. Body may be `{ "input": { ... }, "approved": true }`. File write requires `approved: true`.
- `GET /api/tool-runs` — recent audit trace.
- `POST /api/tasks` — create a task and schedule the bounded task runner; body `{ "objective": "...", "profile_id": "optional-profile" }`; returns HTTP 202.
- `GET /api/tasks` and `GET /api/tasks/{id}` — inspect state, plan, steps, verification, errors and approvals.
- `POST /api/tasks/{id}/approve` — approve the currently waiting write step and resume it.
- `POST /api/tasks/{id}/cancel` — request cancellation; the runner checks it between steps.

Example calculation:

```bash
curl -X POST http://127.0.0.1:8000/api/tasks \
  -H 'Content-Type: application/json' \
  -d '{"objective":"Calculate (12 + 3) * 4"}'
```

## Memory, projects and profiles

- Memories: `GET/POST /api/memories`, `PUT/DELETE /api/memories/{id}`. List supports `scope` and `q` query parameters. A profile uses a configured memory scope plus global memories in the system context.
- Projects: `GET/POST /api/projects`, `DELETE /api/projects/{id}`.
- Profiles: `GET/POST /api/profiles`, `PUT/DELETE /api/profiles/{id}`. Built-in IDs beginning with `omni-` cannot be deleted, but can be edited.

## Errors

API failures use standard HTTP status codes with JSON `{ "detail": "..." }` for normal request paths. Typical cases: `401` missing token, `404` unknown record/tool, `409` write approval needed, `422` invalid typed/validated input, and `502` upstream model failure. Tool-run failure detail is recorded in the audit list; a successful HTTP request to a tool endpoint still does not imply successful result verification unless its payload says so.

For the full generated schema, use `/docs` and `/redoc` while the server is running.
