# Third-party dependency inventory

OMNI's original source code is licensed under MIT. Dependencies are not relicensed by this repository; their own terms apply. The table below records package license metadata for the versions installed/checked during preparation of v0.1.0. A distributable release should regenerate a full SBOM and recheck the exact locked versions during CI/release.

| Package | Role | Version inspected | Declared license metadata | Bundled into the repository? |
|---|---|---:|---|---|
| FastAPI | HTTP API | 0.128.2 | MIT | No; installed as dependency |
| Uvicorn | ASGI server | 0.48.0 | BSD-3-Clause | No; installed as dependency |
| HTTPX | Provider/network client | 0.28.1 | BSD-3-Clause | No; installed as dependency |
| Pydantic | Request validation | 2.13.5 | MIT | No; installed as dependency |
| Starlette | ASGI framework (transitive) | 0.50.0 | BSD-3-Clause | No; installed as dependency |
| AnyIO | Async runtime (transitive) | 4.13.0 | MIT | No; installed as dependency |
| pytest | Test runner (development extra) | 9.0.0 | MIT | No; installed as dependency |

The exact resolved versions at install time depend on the environment because the starter uses compatible version ranges instead of a lock file. Transitive dependencies, a model provider's SDK, model weights, plugin code, fonts supplied by a host OS, or optional inference servers may have additional terms. No external JavaScript package, web font, analytics script, model weight, or search provider code is bundled in the browser UI. Tavily is an optional hosted API: its terms, availability and billing are separate.
