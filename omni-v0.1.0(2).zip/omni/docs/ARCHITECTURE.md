# OMNI architecture (v0.1.0)

## Component map

```text
Browser UI (static HTML/CSS/JS)
        │ HTTP JSON + Server-Sent Events
        ▼
FastAPI API / authentication middleware
        ├── Configuration and profile store ──┐
        ├── Provider adapter                  │
        │     ├── deterministic demo          │ SQLite (WAL)
        │     └── OpenAI-compatible client     │ conversations/messages/settings/profiles/
        ├── Tool registry + permission checks ├ projects/memories/tasks/tool_runs
        │     ├── calculator                   │
        │     ├── workspace read/write/list    │
        │     ├── public URL fetch             │
        │     └── optional Tavily search       │
        ├── trusted Python plugin loader       │
        └── bounded task engine ──────────────┘
                    │
                    └── configured workspace directory
```

The frontend is served from `app/static` by the same FastAPI application. It has no JavaScript package manager step and no remote font/script imports. Markdown rendering in chat is a deliberately small DOM-based subset that does not inject model text as HTML.

## Directory structure

- `app/main.py` — FastAPI routes, request validation, SSE handling, auth middleware, profile/context assembly.
- `app/db.py` — short-lived SQLite connections, schema and additive migrations.
- `app/config.py` — environment paths, runtime defaults, secret lookup.
- `app/providers/` — provider dispatch, deterministic demo, OpenAI-compatible API and SSE stream.
- `app/tools/registry.py` — schema declarations, permission metadata, restricted executors.
- `app/tools/plugins.py` — explicitly opt-in plugin loader for admin-reviewed Python modules.
- `app/agent/engine.py` — deterministic planner, persistent task state, bounded retries/time budget, cancellation checks, approval and verification.
- `app/static/` — responsive single-page browser UI.
- `workspace/` — default user-tool workspace, restricted by path checks.
- `tests/` — API, tool, agent, memory, permission, and plugin tests.
- `docs/` — API, security, architecture, plugin and dependency documentation.

## Persistence model

SQLite tables are `settings`, `conversations`, `messages`, `tasks`, `memories`, `profiles`, `projects`, and `tool_runs`. Foreign keys cascade messages when a conversation is deleted. Schema version is tracked by `PRAGMA user_version`; v0.1.0 uses an additive migration for `tasks.profile_id` and `profiles.memory_scope` so an earlier local database can be upgraded without discarding data.

JSON columns store messages' metadata, task plans/steps/approved step IDs and profile tool allowlists. SQLite connections are short-lived with foreign keys and WAL enabled. There is no ORM dependency and no PostgreSQL adapter yet.

## Provider contract

A provider receives a list of `{role, content}` messages plus resolved configuration. The adapter exposes a full-response method and an asynchronous delta stream. For OpenAI-compatible endpoints, the server sends `/chat/completions` requests and parses `data:` SSE records. The model key is loaded from `OMNI_API_KEY` or `OPENAI_API_KEY`; it is not saved in SQLite or returned to the browser.

The demo provider returns deterministic status/explanation text. Its UI and API explicitly label it as a demo and do not represent its responses as model-generated reasoning.

## Task lifecycle

`RECEIVED → ANALYZED → PLANNED → EXECUTING → VERIFYING → COMPLETED`

The engine also records `WAITING_FOR_APPROVAL`, `RETRYING`, `FAILED`, `CANCELLED`, and `PARTIALLY_COMPLETED`. The v0.1 planner is rules-based and recognizes only a finite set of action shapes. Every step records input, attempts, result, status, and verification message. Approved write steps are stored individually, so approving one step does not blanket-approve all possible actions in a task.

The engine checks a monotonic time budget and cancellation flag between steps. Retries are capped at three. Tool handlers have explicit internal timeouts where network I/O occurs; a plugin's declared timeout is metadata, not hard process pre-emption.

## Security boundaries

- The API binds to localhost by default. Non-local binding through `run.py` requires an access token.
- API auth uses one configured Bearer token when enabled; it does not provide user identities or per-user storage isolation.
- Tools are globally allowlisted. Agent profiles can only narrow this global set, not grant globally disabled tools.
- File tools are restricted to `OMNI_WORKSPACE_DIR`, with path normalization and traversal rejection.
- File writes require confirmation and are logged.
- The arithmetic evaluator parses a limited AST and never calls Python `eval`.
- Network access is a separate setting, disabled by default, and public-address checks are applied before URL retrieval.
- Website/document/tool output is treated as untrusted content; it does not modify privileged tool policy.
- Python plugins are disabled by default and deliberately not described as sandboxed.

## Main API contracts

Request/response details and examples live in [`API.md`](API.md). Schemas are served in the generated OpenAPI spec and checked by FastAPI/Pydantic for the typed routes; configuration/tool schemas receive additional hand validation.
