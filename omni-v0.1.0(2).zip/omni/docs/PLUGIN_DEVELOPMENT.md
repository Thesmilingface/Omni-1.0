# Tool plugin development

OMNI v0.1.0 supports optional Python tool modules loaded at server startup. **Only enable modules written or reviewed by the instance administrator.** A plugin runs inside the OMNI Python process with the same OS permissions as the service; this loader is not a sandbox.

## Disablement by default

Set `OMNI_PLUGIN_DIR=./plugins` to select a directory. Loading stays disabled unless `OMNI_TRUST_PYTHON_PLUGINS=true` is set in the server environment before startup. In production, use a read-only plugin directory owned by the administrator. Do not expose an endpoint allowing untrusted users to upload or edit Python plugins.

Example `plugins/echo_plugin.py`:

```python
PLUGIN = {
    "name": "echo_text",
    "description": "Return the provided string for demonstration.",
    "input_schema": {
        "type": "object",
        "properties": {"text": {"type": "string", "maxLength": 300}},
        "required": ["text"],
        "additionalProperties": False,
    },
    "permissions": [],
    "changes_external_state": False,
    "requires_approval": False,
    "timeout_seconds": 3,
    "execute": lambda args, settings: {"text": args["text"]},
}
```

Restart OMNI after adding the file. Check `GET /api/plugins` and `GET /api/tools` for load state/metadata. The new tool is disabled unless an administrator adds its name to the global `enabled_tools` configuration. Agent profiles impose an additional allowlist, so adding a tool to the global list does not automatically grant it to every profile.

## Contract

A module must export a `PLUGIN` dictionary containing:

- `name`: unique tool identifier matching `[a-z][a-z0-9_-]{1,63}`.
- `description`: non-empty and at most 500 characters.
- `input_schema`: JSON Schema-like object with a `properties` map. Common field `type`, `required`, `additionalProperties`, `maxLength`, `minimum`, and `maximum` constraints are checked by the registry; this is not a complete JSON Schema validator.
- `execute(args, settings)`: callable returning a JSON-serializable dictionary or raising an exception.
- Optional `permissions`, `changes_external_state`, `requires_approval`, and `timeout_seconds` metadata.

A tool should declare the least required permissions, use explicit I/O timeouts, validate all input itself, avoid logging secrets, and make its side effects clear. `timeout_seconds` is currently descriptive metadata for plugins and does not forcibly terminate a stuck plugin function. Do not run untrusted plugin code in the server process; use a separately designed OS/container sandbox if a trust boundary is needed.

For a built-in tool, add its `ToolSpec` in `app/tools/registry.py` and tests under `tests/`. The admin plugin mechanism is intended for reviewed extensions, not a marketplace or arbitrary in-app code execution feature.
