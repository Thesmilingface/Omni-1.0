# Security policy and current controls

## Supported security controls

- Server binds to loopback through `python run.py` by default. If `OMNI_HOST` is non-local, startup requires `OMNI_ACCESS_TOKEN`.
- When set, the bearer token guards API routes other than basic health/auth status. The browser stores it in tab-scoped `sessionStorage` and sends it to the OMNI origin only.
- API secrets for compatible providers and search live in environment variables and are not exposed through `/api/config`.
- The tool registry is globally allowlisted, validates required fields and basic schema constraints, records tool calls, and makes permission/approval metadata inspectable.
- File operations are scoped to a normalized workspace root. Files are UTF-8 text and capped at 1 MB per operation.
- File writes need explicit user approval in both the task flow and manual tool runner.
- Calculator expressions run through a restricted AST visitor, not `eval`.
- Network tools are disabled by default. URL fetch blocks non-HTTP(S), URL credentials, local hostnames, non-global/reserved IP results, redirects, and non-text content.
- Retrieved model, web and document content is input data, not privileged instructions.
- Plugins are disabled by default and require administrator trust opt-in.
- User-visible task state differentiates pending approval, completed execution, failed verification, and unsupported objectives.

## Known risks and limits

OMNI v0.1.0 is an early prototype and has not undergone an external security audit. Do not rely on it for sensitive multi-user or public internet deployments without additional hardening.

- Bearer-token auth is single-user and lacks login rotation, per-user authorization, CSRF model, quotas, and identity-level record separation. Use TLS and a reverse proxy for remote deployment; do not bind an unauthenticated server to a public interface.
- A malicious or compromised model endpoint may receive conversation content sent to it. Configure only endpoints you trust and disclose external processing to users.
- The URL fetcher's DNS/IP validation is defense in depth, not a complete SSRF/network sandbox. DNS rebinding, proxy environment behavior, and deployment topology may create residual risks. Use network egress restrictions and disable network tools if uncertain.
- Python plugins execute with OMNI process permissions and can bypass app-level checks through Python capabilities. Only load trusted reviewed code and mount plugin directories read-only.
- Plugin timeout metadata is not hard pre-emption. Core network handlers have request timeouts; a stuck plugin can consume resources.
- The task engine checks cancellation between steps; an already-running synchronous tool may not stop immediately.
- There is no per-user memory/conversation separation, encryption-at-rest layer, automatic backup scheduler, vector-store isolation, or malware scanning of uploaded files in this release.
- Tool schema checks cover common JSON Schema fields only. Plugins remain responsible for validation beyond those constraints.

## Reporting issues

Please do not publish exploit details for a currently deployed OMNI instance before contacting its maintainer. Until a dedicated private security contact is configured, open a private security advisory in the repository host if supported. Include version, configuration, reproducible steps and impact; redact tokens, endpoint keys, URLs containing secrets, and personal data.

## Safe deployment baseline

1. Keep OMNI on localhost unless remote access is explicitly needed.
2. Set a strong random `OMNI_ACCESS_TOKEN` before any non-local bind.
3. Run as a low-privilege OS account; limit write access to the data and workspace directories.
4. Keep network tools disabled unless they are needed.
5. Do not enable unreviewed Python plugins.
6. Do not expose API keys in browser code, chat prompts, config JSON, logs, or checked-in `.env` files.
7. Back up the database before upgrades and verify task/file operations on a non-production workspace.
