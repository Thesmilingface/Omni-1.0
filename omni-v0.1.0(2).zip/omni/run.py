"""Local entry point. Reads a simple .env file without adding a dotenv dependency."""
from __future__ import annotations
import os
from pathlib import Path
import uvicorn


def load_dotenv_file(path: Path = Path(".env")) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if value.startswith(("'", '"')) and value.endswith(("'", '"')) and len(value) >= 2:
            value = value[1:-1]
        if key and key.replace("_", "").isalnum():
            os.environ.setdefault(key, value)


if __name__ == "__main__":
    load_dotenv_file()
    host = os.environ.get("OMNI_HOST", "127.0.0.1")
    port = int(os.environ.get("OMNI_PORT", "8000"))
    if host not in ("127.0.0.1", "localhost", "::1") and not os.environ.get("OMNI_ACCESS_TOKEN"):
        raise SystemExit("Refusing to bind OMNI beyond localhost without OMNI_ACCESS_TOKEN. Set a long random token first.")
    uvicorn.run("app.main:app", host=host, port=port, reload=False)
