# Optional tool plugins

Drop administrator-reviewed Python modules here only if you enable `OMNI_TRUST_PYTHON_PLUGINS=true`. See `../docs/PLUGIN_DEVELOPMENT.md`. Plugins execute in the OMNI process and are not sandboxed; this directory is empty by default.
