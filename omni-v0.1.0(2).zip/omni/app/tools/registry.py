"""Tool registry and scoped, permission-aware executors."""
from __future__ import annotations
import ast
import ipaddress
import json
import math
import os
import re
import socket
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse
import httpx
from app.config import workspace_dir

class ToolError(RuntimeError):
    pass

@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    input_schema: dict[str, Any]
    permissions: tuple[str, ...]
    changes_external_state: bool
    requires_approval: bool
    timeout_seconds: int
    executor: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]


def _calculator(args: dict[str, Any], _: dict[str, Any]) -> dict[str, Any]:
    expression = str(args.get("expression", "")).strip()
    if not expression or len(expression) > 256:
        raise ToolError("Expression must contain 1–256 characters.")
    expression = expression.replace("^", "**")
    try:
        node = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ToolError("Invalid arithmetic expression.") from exc
    if sum(1 for _ in ast.walk(node)) > 64:
        raise ToolError("Expression is too complex.")
    functions = {"sqrt": math.sqrt, "abs": abs, "round": round, "floor": math.floor, "ceil": math.ceil, "min": min, "max": max, "log": math.log, "log10": math.log10, "sin": math.sin, "cos": math.cos, "tan": math.tan, "pi": math.pi, "e": math.e}
    def visit(n: ast.AST) -> Any:
        if isinstance(n, ast.Expression): return visit(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool): return n.value
        if isinstance(n, ast.Name) and n.id in functions and not callable(functions[n.id]): return functions[n.id]
        if isinstance(n, ast.BinOp) and type(n.op) in (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow):
            left, right = visit(n.left), visit(n.right)
            if isinstance(n.op, ast.Pow) and abs(float(right)) > 100: raise ToolError("Exponent magnitude is limited to 100.")
            if isinstance(n.op, ast.Div) and right == 0 or isinstance(n.op, ast.FloorDiv) and right == 0 or isinstance(n.op, ast.Mod) and right == 0: raise ToolError("Division by zero.")
            if isinstance(n.op, ast.Add): result = left + right
            elif isinstance(n.op, ast.Sub): result = left - right
            elif isinstance(n.op, ast.Mult): result = left * right
            elif isinstance(n.op, ast.Div): result = left / right
            elif isinstance(n.op, ast.FloorDiv): result = left // right
            elif isinstance(n.op, ast.Mod): result = left % right
            else: result = left ** right
            if isinstance(result, (int, float)) and (not math.isfinite(float(result)) or abs(float(result)) > 1e100): raise ToolError("Result is outside the supported numeric range.")
            return result
        if isinstance(n, ast.UnaryOp) and type(n.op) in (ast.UAdd, ast.USub):
            v = visit(n.operand); return v if isinstance(n.op, ast.UAdd) else -v
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in functions and callable(functions[n.func.id]) and not n.keywords:
            return functions[n.func.id](*(visit(arg) for arg in n.args))
        if isinstance(n, ast.Tuple): return tuple(visit(x) for x in n.elts)
        raise ToolError(f"Unsupported expression element: {type(n).__name__}")
    try:
        value = visit(node)
    except ToolError:
        raise
    except (ArithmeticError, ValueError, TypeError, OverflowError) as exc:
        raise ToolError(f"Cannot evaluate expression: {exc}") from exc
    return {"expression": expression, "value": value, "formatted": f"{value:g}" if isinstance(value, float) else str(value)}


def _safe_workspace_path(rel: str) -> Path:
    if not rel or len(rel) > 240:
        raise ToolError("A relative workspace path is required (max 240 characters).")
    root = workspace_dir().resolve()
    candidate = (root / rel).resolve()
    if candidate != root and not candidate.is_relative_to(root):
        raise ToolError("Path escapes the configured OMNI workspace.")
    if candidate == root:
        raise ToolError("Choose a file or subdirectory inside the workspace.")
    return candidate


def _list_workspace(args: dict[str, Any], _: dict[str, Any]) -> dict[str, Any]:
    root = workspace_dir().resolve()
    rel = str(args.get("path", "."))
    target = root if rel == "." else (root / rel).resolve()
    if target != root and not target.is_relative_to(root): raise ToolError("Path escapes the configured OMNI workspace.")
    if not target.exists(): raise ToolError("Directory does not exist.")
    if not target.is_dir(): raise ToolError("Path is not a directory.")
    items = []
    for p in sorted(target.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))[:200]:
        if p.name.startswith("."): continue
        items.append({"name": p.name, "type": "directory" if p.is_dir() else "file", "size": None if p.is_dir() else p.stat().st_size})
    return {"path": "." if target == root else str(target.relative_to(root)), "items": items, "count": len(items)}


def _read_workspace(args: dict[str, Any], _: dict[str, Any]) -> dict[str, Any]:
    path = _safe_workspace_path(str(args.get("path", "")))
    if not path.exists() or not path.is_file(): raise ToolError("File not found in workspace.")
    if path.stat().st_size > 1_000_000: raise ToolError("File is larger than the 1 MB read limit.")
    try: content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc: raise ToolError("Only UTF-8 text files can be read with this tool.") from exc
    return {"path": str(path.relative_to(workspace_dir().resolve())), "content": content, "characters": len(content)}


def _write_workspace(args: dict[str, Any], _: dict[str, Any]) -> dict[str, Any]:
    path = _safe_workspace_path(str(args.get("path", "")))
    content = str(args.get("content", ""))
    if len(content.encode("utf-8")) > 1_000_000: raise ToolError("File content exceeds the 1 MB write limit.")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return {"path": str(path.relative_to(workspace_dir().resolve())), "bytes_written": path.stat().st_size, "verified": path.read_text(encoding="utf-8") == content}


def _assert_public_url(url: str) -> str:
    try: parsed = urlparse(url)
    except ValueError as exc: raise ToolError("Invalid URL.") from exc
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ToolError("Only absolute HTTP(S) URLs are allowed.")
    if parsed.username or parsed.password: raise ToolError("URLs containing credentials are not allowed.")
    host = parsed.hostname.rstrip(".").lower()
    if host == "localhost" or host.endswith(".localhost") or host.endswith(".local"):
        raise ToolError("Local hostnames are blocked by the network tool.")
    try:
        addresses = [ipaddress.ip_address(host)]
    except ValueError:
        try:
            answers = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
            addresses = [ipaddress.ip_address(a[4][0]) for a in answers]
        except (socket.gaierror, OSError, ValueError) as exc:
            raise ToolError("Hostname could not be resolved safely.") from exc
    if not addresses or any(not addr.is_global for addr in addresses):
        raise ToolError("Private, local, reserved, or non-global IP addresses are blocked.")
    return url


def _fetch_url(args: dict[str, Any], settings: dict[str, Any]) -> dict[str, Any]:
    if not settings.get("network_enabled", False): raise ToolError("Network tools are disabled. Enable them in Settings first.")
    url = _assert_public_url(str(args.get("url", "")))
    try:
        with httpx.Client(timeout=12, follow_redirects=False, headers={"User-Agent": "OMNI/0.1 (+local assistant; bounded fetch)"}) as client:
            response = client.get(url)
            if 300 <= response.status_code < 400: raise ToolError("Redirects are blocked; provide the final URL explicitly.")
            response.raise_for_status()
            ctype = response.headers.get("content-type", "")
            if not any(kind in ctype.lower() for kind in ("text/", "application/json", "application/xml", "application/xhtml+xml")):
                raise ToolError(f"Unsupported content type: {ctype[:100]}")
            raw = response.content[:500_000]
            text = raw.decode(response.encoding or "utf-8", errors="replace")
            text = re.sub(r"<script\b[^>]*>[\s\S]*?</script>", " ", text, flags=re.I)
            text = re.sub(r"<style\b[^>]*>[\s\S]*?</style>", " ", text, flags=re.I)
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            return {"url": url, "status_code": response.status_code, "content_type": ctype, "text": text[:20_000], "truncated": len(text) > 20_000 or len(response.content) > 500_000}
    except ToolError: raise
    except httpx.HTTPError as exc: raise ToolError(f"Fetch failed: {str(exc)[:240]}") from exc


def _web_search(args: dict[str, Any], settings: dict[str, Any]) -> dict[str, Any]:
    if not settings.get("network_enabled", False): raise ToolError("Network tools are disabled. Enable them in Settings first.")
    key = os.environ.get("OMNI_TAVILY_API_KEY", "").strip()
    if not key: raise ToolError("Web search is implemented but disconnected: set OMNI_TAVILY_API_KEY in the environment.")
    query = str(args.get("query", "")).strip()
    if not query or len(query) > 500: raise ToolError("Search query must contain 1–500 characters.")
    try:
        response = httpx.post("https://api.tavily.com/search", json={"api_key": key, "query": query, "max_results": min(8, max(1, int(args.get("max_results", 5)))), "search_depth": "basic"}, timeout=15)
        response.raise_for_status()
        data = response.json()
        results = [{"title": r.get("title", ""), "url": r.get("url", ""), "snippet": r.get("content", "")[:1200], "score": r.get("score")} for r in data.get("results", [])]
        return {"query": query, "results": results, "count": len(results), "provider": "Tavily"}
    except (httpx.HTTPError, ValueError) as exc: raise ToolError(f"Search failed: {str(exc)[:240]}") from exc


REGISTRY: dict[str, ToolSpec] = {
    "calculator": ToolSpec("calculator", "Safely evaluate a mathematical expression.", {"type":"object","properties":{"expression":{"type":"string","maxLength":256}},"required":["expression"],"additionalProperties":False}, ("compute",), False, False, 3, _calculator),
    "workspace_list": ToolSpec("workspace_list", "List files and directories inside the configured workspace.", {"type":"object","properties":{"path":{"type":"string","default":"."}},"additionalProperties":False}, ("workspace.read",), False, False, 3, _list_workspace),
    "workspace_read": ToolSpec("workspace_read", "Read a UTF-8 text file from the configured workspace.", {"type":"object","properties":{"path":{"type":"string"}},"required":["path"],"additionalProperties":False}, ("workspace.read",), False, False, 3, _read_workspace),
    "workspace_write": ToolSpec("workspace_write", "Create or replace a UTF-8 text file inside the configured workspace.", {"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string","maxLength":1000000}},"required":["path","content"],"additionalProperties":False}, ("workspace.write",), True, True, 5, _write_workspace),
    "fetch_url": ToolSpec("fetch_url", "Fetch bounded public HTTP(S) text content. Network access must be enabled.", {"type":"object","properties":{"url":{"type":"string","format":"uri"}},"required":["url"],"additionalProperties":False}, ("network",), False, False, 15, _fetch_url),
    "web_search": ToolSpec("web_search", "Search the web through a configured Tavily API key. Network access must be enabled.", {"type":"object","properties":{"query":{"type":"string","maxLength":500},"max_results":{"type":"integer","minimum":1,"maximum":8,"default":5}},"required":["query"],"additionalProperties":False}, ("network",), False, False, 20, _web_search),
}


def public_registry(settings: dict[str, Any]) -> list[dict[str, Any]]:
    enabled = set(settings.get("enabled_tools", []))
    result = []
    for tool in REGISTRY.values():
        result.append({"name": tool.name, "description": tool.description, "input_schema": tool.input_schema,
                       "permissions": list(tool.permissions), "changes_external_state": tool.changes_external_state,
                       "requires_approval": tool.requires_approval, "timeout_seconds": tool.timeout_seconds,
                       "enabled": tool.name in enabled, "connected": tool.name != "web_search" or bool(os.environ.get("OMNI_TAVILY_API_KEY"))})
    return result


def execute_tool(name: str, args: dict[str, Any], settings: dict[str, Any], approved: bool = False) -> dict[str, Any]:
    spec = REGISTRY.get(name)
    if spec is None: raise ToolError(f"Unknown tool: {name}")
    if name not in set(settings.get("enabled_tools", [])): raise ToolError(f"Tool {name!r} is disabled in Settings.")
    if spec.requires_approval and not approved: raise ToolError(f"Approval required before executing {name!r}.")
    # Strict JSON schema checks for the common schema keywords used by built-in tools.
    schema = spec.input_schema
    if not isinstance(args, dict): raise ToolError("Tool input must be a JSON object.")
    if not schema.get("additionalProperties", True):
        unknown = set(args) - set(schema.get("properties", {}))
        if unknown: raise ToolError("Unexpected input fields: " + ", ".join(sorted(unknown)))
    missing = [k for k in schema.get("required", []) if k not in args]
    if missing: raise ToolError("Missing required fields: " + ", ".join(missing))
    for key, value in args.items():
        prop = schema.get("properties", {}).get(key, {})
        if prop.get("type") == "string" and not isinstance(value, str): raise ToolError(f"{key} must be a string.")
        if prop.get("type") == "integer" and (not isinstance(value, int) or isinstance(value, bool)): raise ToolError(f"{key} must be an integer.")
        if isinstance(value, str) and len(value) > prop.get("maxLength", 1_000_000): raise ToolError(f"{key} exceeds maxLength.")
        if isinstance(value, int) and (value < prop.get("minimum", value) or value > prop.get("maximum", value)): raise ToolError(f"{key} is outside the allowed range.")
    return spec.executor(args, settings)
