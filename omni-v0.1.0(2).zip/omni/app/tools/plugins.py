"""Opt-in loader for administrator-trusted Python tool plugins.

Plugin code is executable code with the OMNI process's OS permissions. Loading is disabled by
 default and requires OMNI_TRUST_PYTHON_PLUGINS=true. This is an extension interface, not a sandbox.
"""
from __future__ import annotations
import importlib.util
import os
import re
import sys
from pathlib import Path
from typing import Any
from app.config import workspace_dir
from app.tools.registry import REGISTRY, ToolSpec

_loaded_names: list[str] = []
_status: list[dict[str, Any]] = []


def load_plugins() -> list[dict[str, Any]]:
    global _status, _loaded_names
    for name in _loaded_names:
        REGISTRY.pop(name, None)
    _loaded_names = []
    _status = []
    trusted = os.environ.get("OMNI_TRUST_PYTHON_PLUGINS", "false").lower() == "true"
    plugin_dir = Path(os.environ.get("OMNI_PLUGIN_DIR", str(Path.cwd() / "plugins"))).expanduser().resolve()
    plugin_dir.mkdir(parents=True, exist_ok=True)
    if not trusted:
        return [{"enabled": False, "loaded": [], "message": "Python plugins are disabled. Set OMNI_TRUST_PYTHON_PLUGINS=true only for administrator-reviewed code."}]
    for path in sorted(plugin_dir.glob("*.py")):
        if path.name.startswith("_"):
            continue
        module_name = "omni_admin_plugin_" + re.sub(r"\W+", "_", path.stem)
        try:
            spec = importlib.util.spec_from_file_location(module_name, path)
            if spec is None or spec.loader is None:
                raise ValueError("Could not create an import specification.")
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            manifest = getattr(module, "PLUGIN", None)
            if not isinstance(manifest, dict):
                raise ValueError("Module must export a PLUGIN dictionary.")
            name = manifest.get("name")
            if not isinstance(name, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{1,63}", name):
                raise ValueError("Plugin name must match [a-z][a-z0-9_-]{1,63}.")
            if name in REGISTRY:
                raise ValueError(f"Tool name {name!r} is already registered.")
            description = manifest.get("description")
            schema = manifest.get("input_schema")
            execute = manifest.get("execute")
            permissions = manifest.get("permissions", [])
            timeout = manifest.get("timeout_seconds", 10)
            if not isinstance(description, str) or not description.strip() or len(description) > 500:
                raise ValueError("Plugin description must be a non-empty string under 500 characters.")
            if not isinstance(schema, dict) or schema.get("type") != "object" or not isinstance(schema.get("properties", {}), dict):
                raise ValueError("input_schema must be a JSON Schema object with a properties map.")
            if not callable(execute):
                raise ValueError("Plugin manifest must contain a callable execute(args, settings).")
            if not isinstance(permissions, (list, tuple)) or any(not isinstance(p, str) or len(p) > 80 for p in permissions):
                raise ValueError("permissions must be a list of short strings.")
            if not isinstance(timeout, int) or isinstance(timeout, bool) or not 1 <= timeout <= 60:
                raise ValueError("timeout_seconds must be an integer from 1 to 60.")
            tool = ToolSpec(name=name, description=description.strip(), input_schema=schema,
                            permissions=tuple(permissions), changes_external_state=bool(manifest.get("changes_external_state", False)),
                            requires_approval=bool(manifest.get("requires_approval", False)), timeout_seconds=timeout, executor=execute)
            REGISTRY[name] = tool
            _loaded_names.append(name)
            _status.append({"name": name, "file": path.name, "loaded": True, "description": description.strip()})
        except Exception as exc:
            _status.append({"file": path.name, "loaded": False, "error": str(exc)[:300]})
    return plugin_status()


def plugin_status() -> list[dict[str, Any]]:
    if not _status and os.environ.get("OMNI_TRUST_PYTHON_PLUGINS", "false").lower() != "true":
        return [{"enabled": False, "loaded": [], "message": "Python plugins are disabled. Set OMNI_TRUST_PYTHON_PLUGINS=true only for administrator-reviewed code."}]
    return list(_status)
