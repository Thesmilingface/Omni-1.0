(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const state = { page: 'chat', config: null, conversationId: null, conversations: [], profiles: [], activeProfile: null, tools: [], tasks: [], taskPoll: null, fileText: '', models: null };
  const pageTitles = { chat: 'Chat', agent: 'Agent workspace', projects: 'Projects', models: 'Models', tools: 'Tools & integrations', memory: 'Knowledge & memory', customize: 'Customize', settings: 'Settings' };
  const escapeHtml = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function toast(message, kind = '') {
    const el = document.createElement('div'); el.className = `toast ${kind}`; el.textContent = message;
    $('#toastStack').append(el); setTimeout(() => el.remove(), 4000);
  }
  function authPrompt() { $('#authModal').hidden = false; setTimeout(() => $('#authToken').focus(), 60); }
  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    const token = sessionStorage.getItem('omni_access_token');
    if (token) headers.set('Authorization', `Bearer ${token}`);
    if (options.body && typeof options.body !== 'string') { headers.set('Content-Type', 'application/json'); options.body = JSON.stringify(options.body); }
    const response = await fetch(path, { ...options, headers });
    if (response.status === 401) { authPrompt(); throw new Error('Authentication required. Enter the server access token.'); }
    const contentType = response.headers.get('content-type') || '';
    const data = contentType.includes('application/json') ? await response.json() : await response.text();
    if (!response.ok) throw new Error((data && data.detail) || (typeof data === 'string' ? data : `Request failed (${response.status})`));
    return data;
  }
  function jsonBody(v) { return JSON.stringify(v); }
  function dateShort(value) { try { return new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return ''; } }
  function fullDate(value) { try { return new Date(value).toLocaleString(); } catch { return ''; } }
  function formatBytes(n) { return n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / (1024 * 1024)).toFixed(1)} MB`; }
  function statusClass(s) { return String(s || '').toLowerCase(); }
  function applyTheme(theme) {
    let chosen = theme;
    if (theme === 'system') chosen = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    document.documentElement.dataset.theme = chosen;
  }
  async function setTheme(theme) {
    applyTheme(theme);
    if (state.config) { state.config.theme = theme; try { await api('/api/config', { method: 'PUT', body: { theme } }); } catch { /* theme remains usable for this session */ } }
  }
  function gotoPage(page) {
    if (!pageTitles[page]) return;
    state.page = page;
    $$('.page').forEach(p => p.classList.toggle('active', p.id === `page-${page}`));
    $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === page));
    $('#currentPageTitle').textContent = pageTitles[page];
    document.body.classList.remove('sidebar-open');
    $('#contentScroll').scrollTop = 0;
    if (page === 'agent') loadTasks();
    if (page === 'projects') loadProjects();
    if (page === 'models') loadModels();
    if (page === 'tools') { loadTools(); loadToolRuns(); }
    if (page === 'memory') loadMemories();
    if (page === 'customize') loadProfiles();
    if (page === 'settings') loadSettingsForm();
  }
  function applyProviderStatus(config) {
    const mock = config.provider === 'mock';
    $('#providerLabel').textContent = mock ? 'Offline demo' : 'Model endpoint';
    $('#providerSub').textContent = mock ? 'No LLM connected' : config.model || 'OpenAI-compatible';
    $('#providerDot').className = `status-dot ${mock ? 'warning' : ''}`;
    $('#demoNotice').hidden = !mock;
    $('#connectionPill').innerHTML = `<span class="status-dot ${mock ? 'warning' : ''}"></span><span>${mock ? 'Demo provider' : 'Model configured'}</span>`;
    $('#providerLabel').title = config.provider_note || '';
  }
  function showWelcome(show) {
    $('#chatWelcome').hidden = !show;
    $('#chatThread').hidden = show;
  }
  function appendInline(parent, text) {
    // Tiny safe inline Markdown subset. Text is always inserted as text nodes; HTML is never interpreted.
    const pattern = /(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g;
    let last = 0, match;
    while ((match = pattern.exec(text)) !== null) {
      if (match.index > last) parent.append(document.createTextNode(text.slice(last, match.index)));
      const t = match[0];
      if (t.startsWith('`')) { const code = document.createElement('code'); code.textContent = t.slice(1, -1); parent.append(code); }
      else if (t.startsWith('**')) { const strong = document.createElement('strong'); strong.textContent = t.slice(2, -2); parent.append(strong); }
      else if (t.startsWith('*')) { const em = document.createElement('em'); em.textContent = t.slice(1, -1); parent.append(em); }
      else {
        const inner = /^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/.exec(t);
        if (inner) { const a = document.createElement('a'); a.textContent = inner[1]; a.href = inner[2]; a.target = '_blank'; a.rel = 'noopener noreferrer'; parent.append(a); }
        else parent.append(document.createTextNode(t));
      }
      last = pattern.lastIndex;
    }
    if (last < text.length) parent.append(document.createTextNode(text.slice(last)));
  }
  function renderMarkdown(container, content) {
    container.replaceChildren();
    const lines = String(content || '').split('\n');
    let code = false, codeBuffer = [], list = null;
    const flushList = () => { if (list) { container.append(list); list = null; } };
    const flushCode = () => { const pre = document.createElement('pre'); const codeEl = document.createElement('code'); codeEl.textContent = codeBuffer.join('\n'); pre.append(codeEl); container.append(pre); codeBuffer = []; };
    for (const line of lines) {
      if (line.trim().startsWith('```')) { flushList(); if (code) flushCode(); code = !code; continue; }
      if (code) { codeBuffer.push(line); continue; }
      const h = /^(#{1,3})\s+(.*)$/.exec(line);
      if (h) { flushList(); const heading = document.createElement(`h${h[1].length}`); appendInline(heading, h[2]); container.append(heading); continue; }
      const li = /^\s*[-*]\s+(.*)$/.exec(line);
      if (li) { if (!list) list = document.createElement('ul'); const item = document.createElement('li'); appendInline(item, li[1]); list.append(item); continue; }
      flushList();
      if (!line.trim()) { container.append(document.createElement('br')); continue; }
      const p = document.createElement('div'); appendInline(p, line); container.append(p);
    }
    flushList(); if (code) flushCode();
  }
  function addChatMessage(role, content, meta = {}) {
    showWelcome(false);
    const outer = document.createElement('article'); outer.className = `chat-message ${role}`; if (meta.id) outer.dataset.messageId = meta.id;
    const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.textContent = role === 'user' ? 'Y' : 'O';
    const body = document.createElement('div'); body.className = 'message-body';
    const label = document.createElement('div'); label.className = 'message-meta'; label.textContent = role === 'user' ? 'YOU' : 'OMNI';
    if (meta.demo_mode && role === 'assistant') { const tag = document.createElement('span'); tag.textContent = 'DEMO'; tag.style.color = '#d5b77b'; label.append(tag); }
    if (meta.created_at) { const ts = document.createElement('span'); ts.textContent = dateShort(meta.created_at); label.append(ts); }
    const contentBox = document.createElement('div'); contentBox.className = 'message-content';
    if (role === 'assistant') renderMarkdown(contentBox, content); else contentBox.textContent = content;
    body.append(label, contentBox);
    if (role === 'assistant' && content) {
      const actions = document.createElement('div'); actions.className = 'message-actions';
      const copy = document.createElement('button'); copy.className = 'message-action'; copy.textContent = 'Copy response'; copy.addEventListener('click', async () => { try { await navigator.clipboard.writeText(content); toast('Response copied.', 'success'); } catch { toast('Clipboard access is unavailable in this context.'); } });
      actions.append(copy); body.append(actions);
    }
    outer.append(avatar, body); $('#chatThread').append(outer); $('#chatThread').scrollIntoView({ block: 'end', behavior: 'smooth' }); return { outer, contentBox, body };
  }
  function addTyping() {
    const msg = addChatMessage('assistant', ''); msg.contentBox.replaceChildren();
    const dots = document.createElement('div'); dots.className = 'typing-indicator'; dots.innerHTML = '<span></span><span></span><span></span>'; msg.contentBox.append(dots); return msg;
  }
  async function streamChat(message) {
    const text = message.trim(); if (!text) return;
    $('#chatInput').value = ''; resizeTextarea($('#chatInput')); $('#sendBtn').disabled = true;
    addChatMessage('user', text);
    const responseMsg = addTyping(); let assembled = ''; let streamStarted = false;
    try {
      const headers = { 'Content-Type': 'application/json' }; const token = sessionStorage.getItem('omni_access_token'); if (token) headers.Authorization = `Bearer ${token}`;
      const response = await fetch('/api/chat/stream', { method: 'POST', headers, body: jsonBody({ message: text, conversation_id: state.conversationId, profile_id: $('#chatProfileSelect').value || state.config?.default_profile || 'omni-general' }) });
      if (response.status === 401) { authPrompt(); throw new Error('Authentication required.'); }
      if (!response.ok) { let detail = `Request failed (${response.status})`; try { detail = (await response.json()).detail || detail; } catch {} throw new Error(detail); }
      if (!response.body) throw new Error('Streaming is not supported by this browser.');
      const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = '';
      const consume = (block) => {
        for (const line of block.split('\n')) {
          if (!line.startsWith('data:')) continue;
          let evt; try { evt = JSON.parse(line.slice(5).trim()); } catch { continue; }
          if (evt.type === 'delta') {
            if (!streamStarted) { responseMsg.contentBox.replaceChildren(); streamStarted = true; }
            assembled += evt.content; renderMarkdown(responseMsg.contentBox, assembled); $('#contentScroll').scrollTop = $('#contentScroll').scrollHeight;
          } else if (evt.type === 'done') {
            state.conversationId = evt.conversation_id; state.config = state.config || {}; state.config.provider = evt.provider; state.config.model = evt.model; applyProviderStatus(state.config);
            if (!assembled) { responseMsg.contentBox.textContent = ''; }
            const metaTag = document.createElement('span'); metaTag.textContent = evt.demo_mode ? 'DEMO' : `${evt.model || ''}`; metaTag.style.color = evt.demo_mode ? '#d5b77b' : '#79cba2'; responseMsg.outer.querySelector('.message-meta').append(metaTag);
            const actions = document.createElement('div'); actions.className = 'message-actions'; const copy = document.createElement('button'); copy.className = 'message-action'; copy.textContent = 'Copy response'; copy.addEventListener('click', async () => { try { await navigator.clipboard.writeText(assembled); toast('Response copied.', 'success'); } catch { toast('Clipboard unavailable.'); } }); actions.append(copy); responseMsg.body.append(actions);
            loadConversations();
          } else if (evt.type === 'error') { throw new Error(evt.error || 'Provider error'); }
        }
      };
      while (true) { const { value, done } = await reader.read(); if (done) break; buffer += decoder.decode(value, { stream: true }); const parts = buffer.split(/\r?\n\r?\n/); buffer = parts.pop() || ''; for (const part of parts) consume(part); }
      if (buffer.trim()) consume(buffer);
      if (!streamStarted && !assembled) { responseMsg.contentBox.textContent = 'The provider returned an empty response.'; }
    } catch (error) {
      responseMsg.contentBox.textContent = `Request error: ${error.message}`; toast(error.message, 'error');
    } finally { $('#sendBtn').disabled = false; $('#chatInput').focus(); }
  }
  function resizeTextarea(el) { el.style.height = 'auto'; el.style.height = `${Math.min(el.scrollHeight, 190)}px`; }
  async function loadConversations() {
    try {
      state.conversations = await api('/api/conversations'); const host = $('#conversationList'); host.replaceChildren();
      if (!state.conversations.length) { const hint = document.createElement('div'); hint.className = 'muted small pad-left'; hint.textContent = 'Your conversations appear here.'; host.append(hint); return; }
      for (const c of state.conversations) {
        const b = document.createElement('button'); b.className = `conversation-item ${state.conversationId === c.id ? 'selected' : ''}`; b.title = c.title;
        const glyph = document.createElement('span'); glyph.className = 'conversation-glyph'; glyph.textContent = '◌';
        const title = document.createElement('span'); title.className = 'conversation-title'; title.textContent = c.title || 'New conversation';
        const del = document.createElement('span'); del.className = 'conversation-delete'; del.textContent = '×'; del.title = 'Delete conversation'; del.setAttribute('role', 'button'); del.addEventListener('click', async e => { e.stopPropagation(); if (!confirm('Delete this conversation and its messages?')) return; try { await api(`/api/conversations/${c.id}`, { method: 'DELETE' }); if (state.conversationId === c.id) newChat(); await loadConversations(); toast('Conversation deleted.', 'success'); } catch (err) { toast(err.message, 'error'); } });
        b.append(glyph, title, del); b.addEventListener('click', () => openConversation(c.id)); host.append(b);
      }
    } catch (err) { if (!/Authentication required/.test(err.message)) console.error(err); }
  }
  async function openConversation(id) {
    try { const data = await api(`/api/conversations/${id}`); state.conversationId = id; $('#chatThread').replaceChildren();
      if (!data.messages.length) showWelcome(true); else { showWelcome(false); for (const msg of data.messages) addChatMessage(msg.role, msg.content, { id: msg.id, created_at: msg.created_at, demo_mode: msg.metadata?.demo_mode }); }
      $$('.conversation-item').forEach(b => b.classList.toggle('selected', b.title === data.conversation.title)); gotoPage('chat'); await loadConversations();
    } catch (err) { toast(err.message, 'error'); }
  }
  function newChat() { state.conversationId = null; $('#chatThread').replaceChildren(); showWelcome(true); $$('.conversation-item').forEach(b => b.classList.remove('selected')); gotoPage('chat'); $('#chatInput').focus(); }

  async function loadSettings() {
    try { state.config = await api('/api/config'); applyProviderStatus(state.config); applyTheme(state.config.theme || 'dark'); populateRuntimeProfileSelectors(); }
    catch (err) { if (!/Authentication required/.test(err.message)) toast(`Could not load configuration: ${err.message}`, 'error'); }
  }
  function toolInputControl(key, schema) {
    const wrap = document.createElement('div'); wrap.className = 'field'; const label = document.createElement('label'); label.htmlFor = `tool-param-${key}`; label.textContent = key.replaceAll('_', ' '); wrap.append(label);
    let control;
    if (key === 'content' || key === 'expression' || key === 'query') { control = document.createElement('textarea'); control.rows = key === 'content' ? 5 : 2; control.placeholder = schema.description || `Enter ${key}`; }
    else { control = document.createElement('input'); control.type = schema.type === 'integer' ? 'number' : 'text'; control.placeholder = schema.default !== undefined ? String(schema.default) : `Enter ${key}`; if (schema.maximum !== undefined) control.max = schema.maximum; if (schema.minimum !== undefined) control.min = schema.minimum; }
    control.id = `tool-param-${key}`; control.dataset.param = key; if (schema.default !== undefined) control.value = schema.default; if (schema.maxLength) control.maxLength = schema.maxLength; if (schema.type === 'integer') control.step = '1'; wrap.append(control); return wrap;
  }
  function selectedTool() { return state.tools.find(t => t.name === $('#toolSelect').value); }
  function renderToolFields() {
    const tool = selectedTool(); const host = $('#toolFields'); host.replaceChildren(); $('#toolApproval').hidden = !tool?.requires_approval; $('#toolApproved').checked = false;
    if (!tool) return;
    for (const [key, schema] of Object.entries(tool.input_schema.properties || {})) {
      if (tool.input_schema.required?.includes(key) || schema.default !== undefined) host.append(toolInputControl(key, schema));
    }
    $('#runToolBtn').disabled = !tool.enabled;
    $('#runToolBtn').textContent = tool.enabled ? 'Execute tool ↗' : 'Tool disabled in Settings';
  }
  async function loadTools() {
    try {
      state.tools = await api('/api/tools');
      const selector = $('#toolSelect'); const old = selector.value; selector.replaceChildren();
      for (const tool of state.tools) { const opt = document.createElement('option'); opt.value = tool.name; opt.textContent = tool.name; selector.append(opt); }
      if ([...selector.options].some(o => o.value === old)) selector.value = old;
      selector.onchange = renderToolFields; renderToolFields();
      $('#toolCatalog').replaceChildren();
      const symbols = { calculator: '∑', workspace_list: '▤', workspace_read: '⌕', workspace_write: '✎', fetch_url: '↗', web_search: '⌕' };
      for (const tool of state.tools) {
        const card = document.createElement('article'); card.className = 'tool-card';
        const top = document.createElement('div'); top.className = 'tool-card-top'; const icon = document.createElement('div'); icon.className = 'tool-card-icon'; icon.textContent = symbols[tool.name] || '⌘';
        const body = document.createElement('div'); const title = document.createElement('h3'); title.textContent = tool.name; const desc = document.createElement('p'); desc.textContent = tool.description; body.append(title, desc); top.append(icon, body); card.append(top);
        const badges = document.createElement('div'); badges.className = 'tool-badges';
        const enabled = document.createElement('span'); enabled.className = `tool-badge ${tool.enabled ? '' : 'off'}`; enabled.textContent = tool.enabled ? 'ENABLED' : 'DISABLED'; badges.append(enabled);
        if (tool.requires_approval) { const b = document.createElement('span'); b.className = 'tool-badge off'; b.textContent = 'APPROVAL'; badges.append(b); }
        for (const permission of tool.permissions) { const b = document.createElement('span'); b.className = 'tool-badge'; b.textContent = permission; badges.append(b); }
        if (!tool.connected) { const b = document.createElement('span'); b.className = 'tool-badge off'; b.textContent = 'KEY MISSING'; badges.append(b); }
        card.append(badges); card.addEventListener('click', () => { $('#toolSelect').value = tool.name; renderToolFields(); $('#toolRunner')?.scrollIntoView({ behavior: 'smooth' }); }); $('#toolCatalog').append(card);
      }
      if (state.config) { $('#networkStatusTag').textContent = state.config.network_enabled ? 'NETWORK ON' : 'NETWORK OFF'; }
      loadSettingToolChecks();
    } catch (err) { toast(err.message, 'error'); }
  }
  async function runToolForm(event) {
    event.preventDefault(); const tool = selectedTool(); if (!tool) return;
    if (!tool.enabled) { toast('Enable this tool in Settings first.', 'error'); return; }
    if (tool.requires_approval && !$('#toolApproved').checked) { toast('Confirm the file operation before execution.', 'error'); return; }
    const args = {};
    for (const el of $$('[data-param]', $('#toolFields'))) {
      let value = el.value; if (el.type === 'number') value = value === '' ? undefined : Number(value);
      if (value === undefined || (typeof value === 'string' && !value.trim())) { if (tool.input_schema.required?.includes(el.dataset.param)) { toast(`Enter ${el.dataset.param}.`, 'error'); return; } else continue; }
      args[el.dataset.param] = value;
    }
    $('#runToolBtn').disabled = true; $('#runToolBtn').textContent = 'Executing…'; $('#toolOutput').hidden = false; $('#toolOutput').innerHTML = '<pre>Waiting for tool result…</pre>';
    try { const data = await api(`/api/tools/${tool.name}/execute`, { method: 'POST', body: { input: args, approved: !!$('#toolApproved').checked } }); $('#toolOutput').innerHTML = ''; const pre = document.createElement('pre'); pre.textContent = JSON.stringify(data, null, 2); $('#toolOutput').append(pre); toast('Tool executed. Output recorded in audit log.', 'success'); await loadToolRuns(); }
    catch (err) { $('#toolOutput').innerHTML = ''; const pre = document.createElement('pre'); pre.textContent = `Tool failed\n${err.message}`; $('#toolOutput').append(pre); toast(err.message, 'error'); await loadToolRuns(); }
    finally { $('#runToolBtn').disabled = false; renderToolFields(); }
  }
  async function loadToolRuns() {
    try { const items = await api('/api/tool-runs'); const host = $('#toolRunsList'); host.replaceChildren(); if (!items.length) { host.innerHTML = '<div class="empty-state">No tool executions recorded.</div>'; return; }
      for (const item of items) { const row = document.createElement('div'); row.className = 'audit-item'; const icon = document.createElement('div'); icon.className = 'audit-icon'; icon.textContent = item.status === 'completed' ? '✓' : '×'; const main = document.createElement('div'); main.className = 'audit-item-main'; const title = document.createElement('strong'); title.textContent = item.tool_name; const detail = document.createElement('small'); detail.textContent = item.error || JSON.stringify(item.output).slice(0, 170); main.append(title, detail); const status = document.createElement('span'); status.className = `audit-status ${item.status === 'failed' ? 'failed' : ''}`; status.textContent = item.status.toUpperCase(); row.append(icon, main, status); host.append(row); }
    } catch (err) { console.error(err); }
  }

  async function loadTasks() {
    try { state.tasks = await api('/api/tasks'); renderTasks(); const active = state.tasks.some(t => ['RECEIVED','ANALYZED','PLANNED','EXECUTING','VERIFYING','RETRYING'].includes(t.status)); if (active && !state.taskPoll) state.taskPoll = setInterval(loadTasks, 1800); else if (!active && state.taskPoll) { clearInterval(state.taskPoll); state.taskPoll = null; } }
    catch (err) { if (!/Authentication required/.test(err.message)) console.error(err); }
  }
  function renderTasks() {
    const host = $('#taskList'); host.replaceChildren(); if (!state.tasks.length) { const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'No tasks yet. Submit an objective above to begin.'; host.append(empty); return; }
    for (const task of state.tasks) {
      const card = document.createElement('article'); card.className = 'task-card'; const top = document.createElement('div'); top.className = 'task-card-top'; const titleBox = document.createElement('div'); const title = document.createElement('h3'); title.textContent = task.objective; const id = document.createElement('div'); id.className = 'task-id'; id.textContent = `${task.id.slice(0,8)} · Updated ${dateShort(task.updated_at)}`; titleBox.append(title,id); const status = document.createElement('span'); status.className = `task-status ${statusClass(task.status)}`; status.textContent = task.status.replaceAll('_',' '); top.append(titleBox,status); card.append(top);
      const steps = task.steps || []; const done = steps.filter(s => s.status === 'completed').length; const percent = steps.length ? Math.round(done / steps.length * 100) : (task.status === 'RECEIVED' ? 4 : 8); const progress = document.createElement('div'); progress.className = 'task-progress'; const bar = document.createElement('span'); bar.style.width = `${percent}%`; progress.append(bar); card.append(progress);
      if (steps.length) { const list = document.createElement('div'); list.className = 'task-steps'; for (const step of steps) { const r = document.createElement('div'); r.className = `task-step ${step.status === 'completed' ? 'done' : step.status === 'failed' ? 'failed' : ''}`; const mark = document.createElement('span'); mark.className = 'step-mark'; mark.textContent = step.status === 'completed' ? '✓' : step.status === 'failed' ? '×' : step.status === 'waiting_for_approval' ? '!' : '·'; const cont = document.createElement('div'); cont.className = 'task-step-content'; const t = document.createElement('strong'); t.textContent = step.title; const desc = document.createElement('small'); let detail = step.error || step.verification?.message || (step.result ? JSON.stringify(step.result).slice(0,180) : step.status); if (step.attempts) detail += ` · attempts: ${step.attempts}`; desc.textContent = detail; cont.append(t,desc); r.append(mark,cont); list.append(r); } card.append(list); }
      if (task.result || task.error) { const note = document.createElement('div'); note.className = 'muted small'; note.style.marginTop = '10px'; note.textContent = task.error || task.result; card.append(note); }
      const actions = document.createElement('div'); actions.className = 'task-card-actions';
      if (task.status === 'WAITING_FOR_APPROVAL') { const approve = document.createElement('button'); approve.className = 'primary-btn'; approve.textContent = 'Approve & continue ✓'; approve.addEventListener('click', async () => { if (!confirm('Approve the pending file write in the OMNI workspace?')) return; try { await api(`/api/tasks/${task.id}/approve`, { method: 'POST' }); toast('Approval recorded; task resumed.', 'success'); loadTasks(); } catch (err) { toast(err.message, 'error'); } }); actions.append(approve); }
      if (!['COMPLETED','FAILED','CANCELLED','PARTIALLY_COMPLETED'].includes(task.status)) { const cancel = document.createElement('button'); cancel.className = 'secondary-btn'; cancel.textContent = 'Cancel task'; cancel.addEventListener('click', async () => { try { await api(`/api/tasks/${task.id}/cancel`, { method: 'POST' }); toast('Cancellation requested.'); loadTasks(); } catch (err) { toast(err.message, 'error'); } }); actions.append(cancel); }
      if (actions.childNodes.length) card.append(actions); host.append(card);
    }
  }
  async function createTask(event) {
    event.preventDefault(); const objective = $('#taskObjective').value.trim(); if (!objective) return;
    const submit = $('#taskForm button[type=submit]'); submit.disabled = true; submit.textContent = 'Submitting…';
    try { const task = await api('/api/tasks', { method: 'POST', body: { objective, profile_id: $('#taskProfile').value || state.config?.default_profile || 'omni-general' } }); $('#taskObjective').value = ''; toast('Task submitted; execution trace is being persisted.', 'success'); state.tasks = [task, ...state.tasks.filter(t => t.id !== task.id)]; renderTasks(); await loadTasks(); }
    catch (err) { toast(err.message, 'error'); }
    finally { submit.disabled = false; submit.innerHTML = 'Start task <span>↗</span>'; }
  }

  async function loadProjects() {
    try { const projects = await api('/api/projects'); const host = $('#projectList'); host.replaceChildren(); if (!projects.length) { host.innerHTML = '<div class="empty-state">Create a project to organize related tasks and notes.</div>'; return; }
      for (const p of projects) { const card = document.createElement('article'); card.className='project-card'; const head=document.createElement('div');head.className='project-card-head';const icon=document.createElement('div');icon.className='project-icon';icon.textContent='▧';const del=document.createElement('button');del.className='text-icon-btn';del.textContent='×';del.title='Delete project';del.addEventListener('click',async()=>{if(!confirm(`Delete project "${p.name}"?`))return;try{await api(`/api/projects/${p.id}`,{method:'DELETE'});loadProjects();toast('Project deleted.','success')}catch(e){toast(e.message,'error')}});head.append(icon,del);const h=document.createElement('h3');h.textContent=p.name;const d=document.createElement('p');d.textContent=p.description||'No description provided.';const meta=document.createElement('small');meta.textContent=`UPDATED ${dateShort(p.updated_at).toUpperCase()}`;card.append(head,h,d,meta);host.append(card); }
    } catch (err) { toast(err.message, 'error'); }
  }
  async function createProject(event) { event.preventDefault(); try { const data = await api('/api/projects',{method:'POST',body:{name:$('#projectName').value.trim(),description:$('#projectDescription').value.trim()}}); $('#projectForm').reset(); toast(`Project “${data.name}” created.`, 'success'); loadProjects(); } catch(err) { toast(err.message,'error'); } }

  async function loadModels() {
    $('#modelList').innerHTML='<div class="empty-state">Checking provider…</div>';
    try { const data = await api('/api/models'); state.models=data; const settings=state.config||await api('/api/config');
      $('#modelConnectionStatus').textContent=data.connected?'ENDPOINT RESPONDED':'NOT CONNECTED'; $('#modelConnectionStatus').style.color=data.connected?'var(--green)':'var(--amber)';
      $('#modelOverview').innerHTML=''; const card1=document.createElement('div');card1.className='model-summary-card';const a=document.createElement('small');a.textContent='ACTIVE PROVIDER';const b=document.createElement('strong');b.textContent=settings.provider==='mock'?'Offline demo':settings.provider;const c=document.createElement('div');c.className='model-sub';c.textContent=settings.provider==='mock'?'Deterministic responses · no LLM':settings.base_url;card1.append(a,b,c);const card2=document.createElement('div');card2.className='model-summary-card';const d=document.createElement('small');d.textContent='ACTIVE MODEL';const e=document.createElement('strong');e.textContent=data.active_model||settings.model;const f=document.createElement('div');f.className='model-sub';f.textContent=data.connected?'Connection check returned successfully':(data.note||'Connection has not been verified');card2.append(d,e,f);$('#modelOverview').append(card1,card2);
      const host=$('#modelList');host.replaceChildren();if(!data.models.length){const empty=document.createElement('div');empty.className='empty-state';empty.textContent=data.note||'No models were returned by this endpoint.';host.append(empty)}
      for(const model of data.models){const row=document.createElement('div');row.className='model-item';const icon=document.createElement('div');icon.className='model-icon';icon.textContent='◈';const main=document.createElement('div');main.className='model-item-main';const title=document.createElement('strong');title.textContent=model.id;const small=document.createElement('small');small.textContent=model.description||model.object||'Model discovered by configured endpoint';main.append(title,small);const tag=document.createElement('span');tag.className='model-active';tag.textContent=model.id===data.active_model?'ACTIVE':'AVAILABLE';if(model.id!==data.active_model){const use=document.createElement('button');use.className='secondary-btn';use.textContent='Use model';use.addEventListener('click',async()=>{try{await api('/api/config',{method:'PUT',body:{model:model.id}});await loadSettings();await loadModels();toast(`Active model set to ${model.id}.`,'success')}catch(err){toast(err.message,'error')}});row.append(icon,main,use)}else row.append(icon,main,tag);host.append(row)}
      $('#providerLabel').title=data.note||'';
    } catch(err){ $('#modelList').innerHTML='';const e=document.createElement('div');e.className='empty-state';e.textContent=err.message;$('#modelList').append(e); }
  }

  async function loadMemories() {
    try { const q=$('#memorySearch').value.trim();const items=await api(`/api/memories${q?'?q='+encodeURIComponent(q):''}`);const host=$('#memoryList');host.replaceChildren();if(!items.length){const e=document.createElement('div');e.className='empty-state';e.textContent=q?'No matching memories.':'No memories stored yet. Add one to start building explicit context.';host.append(e);return;}
      for(const m of items){const card=document.createElement('article');card.className='memory-card';const top=document.createElement('div');top.className='memory-card-top';const category=document.createElement('span');category.className='memory-category';category.textContent=m.category;const scope=document.createElement('span');scope.className='memory-scope';scope.textContent=`SCOPE · ${m.scope}`;top.append(category,scope);const content=document.createElement('div');content.className='memory-card-content';content.textContent=m.content;const bottom=document.createElement('div');bottom.className='memory-card-bottom';const date=document.createElement('span');date.textContent=`UPDATED ${dateShort(m.updated_at).toUpperCase()}`;const actions=document.createElement('div');actions.className='memory-actions';const edit=document.createElement('button');edit.className='small-btn';edit.textContent='Edit';edit.addEventListener('click',async()=>{const value=prompt('Edit memory content',m.content);if(value===null)return;if(!value.trim()){toast('Memory content cannot be empty.','error');return}try{await api(`/api/memories/${m.id}`,{method:'PUT',body:{content:value}});await loadMemories();toast('Memory updated.','success')}catch(err){toast(err.message,'error')}});const del=document.createElement('button');del.className='small-btn';del.textContent='Delete';del.addEventListener('click',async()=>{if(!confirm('Permanently delete this memory?'))return;try{await api(`/api/memories/${m.id}`,{method:'DELETE'});await loadMemories();toast('Memory deleted.','success')}catch(err){toast(err.message,'error')}});actions.append(edit,del);bottom.append(date,actions);card.append(top,content,bottom);host.append(card)}
    }catch(err){toast(err.message,'error')}
  }
  async function createMemory(event){event.preventDefault();try{await api('/api/memories',{method:'POST',body:{content:$('#memoryContent').value.trim(),category:$('#memoryCategory').value,scope:$('#memoryScope').value.trim()||'global'}});$('#memoryContent').value='';toast('Memory saved.','success');loadMemories()}catch(err){toast(err.message,'error')}}

  async function loadProfiles() {
    try { state.profiles=await api('/api/profiles');const host=$('#profileList');host.replaceChildren();if(!state.profiles.length){host.textContent='No profiles configured.';return}
      for(const p of state.profiles){const b=document.createElement('button');b.className=`profile-list-item ${state.activeProfile===p.id?'active':''}`;const strong=document.createElement('strong');strong.textContent=p.name;const small=document.createElement('small');small.textContent=p.description||'No description';b.append(strong,small);b.addEventListener('click',()=>selectProfile(p.id));host.append(b)}
      if(!state.activeProfile||!state.profiles.some(p=>p.id===state.activeProfile)) selectProfile(state.profiles[0].id,false);
      populateDefaultProfileSelect();populateRuntimeProfileSelectors();
    }catch(err){toast(err.message,'error')}
  }
  function selectProfile(id, updateList=true){const p=state.profiles.find(x=>x.id===id);if(!p)return;state.activeProfile=id;$('#profileId').value=p.id;$('#profileName').value=p.name;$('#profileDescription').value=p.description||'';$('#profileInstructions').value=p.instructions||'';$('#profileProvider').value=p.provider||'';$('#profileModel').value=p.model||'';$('#profileTemperature').value=p.temperature??.3;$('#profileMemoryScope').value=p.memory_scope||'global';$('#profileTempValue').textContent=Number($('#profileTemperature').value).toFixed(1);$('#profileEditorTitle').textContent=p.name;$('#deleteProfile').hidden=p.id.startsWith('omni-');$('#profileTools').replaceChildren();for(const t of state.tools){const label=document.createElement('label');label.className='tool-check';const input=document.createElement('input');input.type='checkbox';input.value=t.name;input.checked=(p.tools||[]).includes(t.name);const text=document.createElement('span');text.textContent=t.name;const desc=document.createElement('small');desc.textContent=t.description;text.append(desc);label.append(input,text);$('#profileTools').append(label)}if(updateList){$$('.profile-list-item').forEach(el=>el.classList.toggle('active',el.querySelector('strong')?.textContent===p.name))}}
  function populateDefaultProfileSelect(){const sel=$('#settingProfile');if(!sel)return;const old=sel.value;sel.replaceChildren();for(const p of state.profiles){const o=document.createElement('option');o.value=p.id;o.textContent=p.name;sel.append(o)}if(old&&[...sel.options].some(o=>o.value===old))sel.value=old;else if(state.config?.default_profile)sel.value=state.config.default_profile;}
  function populateRuntimeProfileSelectors(){for(const selector of ['#chatProfileSelect','#taskProfile']){const sel=$(selector);if(!sel)continue;const old=sel.value;sel.replaceChildren();for(const p of state.profiles){const o=document.createElement('option');o.value=p.id;o.textContent=p.name;sel.append(o)}if(old&&[...sel.options].some(o=>o.value===old))sel.value=old;else if(state.config?.default_profile)sel.value=state.config.default_profile;else if(sel.options.length)sel.selectedIndex=0}}
  async function saveProfile(event){event.preventDefault();const id=$('#profileId').value;const body={name:$('#profileName').value.trim(),description:$('#profileDescription').value.trim(),instructions:$('#profileInstructions').value,provider:$('#profileProvider').value,model:$('#profileModel').value.trim(),temperature:Number($('#profileTemperature').value),memory_scope:$('#profileMemoryScope').value.trim()||'global',tools:$$('#profileTools input:checked').map(x=>x.value)};try{const saved=await api(id?`/api/profiles/${id}`:'/api/profiles',{method:id?'PUT':'POST',body});state.activeProfile=saved.id;await loadProfiles();selectProfile(saved.id);toast('Profile saved.','success')}catch(err){toast(err.message,'error')}}
  async function deleteProfile(){const id=$('#profileId').value;if(!id||id.startsWith('omni-'))return;if(!confirm('Delete this custom profile?'))return;try{await api(`/api/profiles/${id}`,{method:'DELETE'});state.activeProfile=null;await loadProfiles();toast('Profile deleted.','success')}catch(err){toast(err.message,'error')}}
  function newProfile(){state.activeProfile=null;$('#profileId').value='';$('#profileName').value='New profile';$('#profileDescription').value='Custom OMNI behavior profile';$('#profileInstructions').value='';$('#profileProvider').value='';$('#profileModel').value='';$('#profileTemperature').value=.3;$('#profileMemoryScope').value='global';$('#profileTempValue').textContent='0.3';$('#profileEditorTitle').textContent='New profile';$('#deleteProfile').hidden=true;$('#profileTools').replaceChildren();for(const t of state.tools){const label=document.createElement('label');label.className='tool-check';const input=document.createElement('input');input.type='checkbox';input.value=t.name;const text=document.createElement('span');text.textContent=t.name;label.append(input,text);$('#profileTools').append(label)}$('#profileName').focus()}

  async function loadSettingsForm(){
    try{const cfg=state.config=await api('/api/config');$('#settingProvider').value=cfg.provider;$('#settingBaseUrl').value=cfg.base_url;$('#settingModel').value=cfg.model;$('#settingTemperature').value=cfg.temperature;$('#settingTemperatureValue').textContent=Number(cfg.temperature).toFixed(1);$('#settingMaxTokens').value=cfg.max_tokens;$('#settingInstructions').value=cfg.system_instructions;$('#settingRetries').value=String(cfg.task_retry_limit);$('#settingTimeout').value=cfg.task_timeout_seconds;$('#settingNetwork').checked=!!cfg.network_enabled;$('#settingTheme').value=cfg.theme||'dark';$('#keyStatusText').textContent=cfg.api_key_configured?'Model API key is configured in the server environment':(cfg.provider==='mock'?'No API key required for the demo provider':'No API key detected; the endpoint may still allow unauthenticated local access');$('#keyStatusDot').className=`status-dot ${cfg.api_key_configured?'':'warning'}`;await loadToolsForSettings();populateDefaultProfileSelect();$('#settingProfile').value=cfg.default_profile||'omni-general';populateRuntimeProfileSelectors();}catch(err){toast(err.message,'error')}
  }
  async function loadToolsForSettings(){try{state.tools=await api('/api/tools');loadSettingToolChecks()}catch(err){console.error(err)}}
  function loadSettingToolChecks(){const host=$('#settingTools');if(!host||!state.tools.length)return;const previous=host.dataset.loaded==='1';const checked=new Set(previous?$$('input:checked',host).map(x=>x.value):(state.config?.enabled_tools||[]));host.replaceChildren();for(const t of state.tools){const label=document.createElement('label');label.className='tool-check';const input=document.createElement('input');input.type='checkbox';input.value=t.name;input.checked=checked.has(t.name)||(!previous&&t.enabled);const span=document.createElement('span');span.textContent=t.name;const small=document.createElement('small');small.textContent=t.permissions.join(' · ');span.append(small);label.append(input,span);host.append(label)}host.dataset.loaded='1'}
  async function saveSettingsForm(event){event.preventDefault();const body={provider:$('#settingProvider').value,base_url:$('#settingBaseUrl').value.trim(),model:$('#settingModel').value.trim(),temperature:Number($('#settingTemperature').value),max_tokens:Number($('#settingMaxTokens').value),system_instructions:$('#settingInstructions').value,task_retry_limit:Number($('#settingRetries').value),task_timeout_seconds:Number($('#settingTimeout').value),network_enabled:$('#settingNetwork').checked,enabled_tools:$$('#settingTools input:checked').map(x=>x.value),default_profile:$('#settingProfile').value,theme:$('#settingTheme').value};$('#settingsSaveStatus').textContent='Saving…';try{state.config=await api('/api/config',{method:'PUT',body});applyProviderStatus(state.config);applyTheme(state.config.theme);$('#settingsSaveStatus').textContent='Saved successfully.';toast('Configuration saved.','success');await loadTools();await loadConversations()}catch(err){$('#settingsSaveStatus').textContent=`Save failed: ${err.message}`;toast(err.message,'error')}}

  // Event wiring
  $$('.nav-item').forEach(b=>b.addEventListener('click',()=>gotoPage(b.dataset.page)));
  $$('[data-goto]').forEach(b=>b.addEventListener('click',()=>gotoPage(b.dataset.goto)));
  $('#newChat').addEventListener('click',newChat);$('#refreshConversations').addEventListener('click',loadConversations);
  $('#chatForm').addEventListener('submit',e=>{e.preventDefault();streamChat($('#chatInput').value+(state.fileText?'\n\nAttached text file:\n'+state.fileText:''));state.fileText='';});
  $('#chatInput').addEventListener('input',()=>resizeTextarea($('#chatInput')));$('#chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('#chatForm').requestSubmit()}});
  $$('.suggestion-card').forEach(b=>b.addEventListener('click',()=>{const prompt=b.dataset.prompt;$('#chatInput').value=prompt;resizeTextarea($('#chatInput'));$('#chatInput').focus()}));
  $('#attachBtn').addEventListener('click',()=>$('#fileInput').click());$('#fileInput').addEventListener('change',async()=>{const file=$('#fileInput').files?.[0];if(!file)return;if(file.size>500_000){toast('Text attachment limit is 500 KB.','error');$('#fileInput').value='';return}try{state.fileText=await file.text();$('#chatInput').value+=`\n\n[Attached: ${file.name}]`;resizeTextarea($('#chatInput'));toast(`${file.name} is attached as text for this message.`,'success')}catch{toast('Could not read this file.','error')}});
  $('#taskForm').addEventListener('submit',createTask);$('#refreshTasks').addEventListener('click',loadTasks);
  $('#projectForm').addEventListener('submit',createProject);
  $('#refreshModels').addEventListener('click',loadModels);$('#toolForm').addEventListener('submit',runToolForm);$('#refreshToolRuns').addEventListener('click',loadToolRuns);
  $('#memoryForm').addEventListener('submit',createMemory);$('#memorySearch').addEventListener('input',()=>{clearTimeout(window.omniMemorySearchTimer);window.omniMemorySearchTimer=setTimeout(loadMemories,250)});$('#clearMemorySearch').addEventListener('click',()=>{$('#memorySearch').value='';loadMemories()});
  $('#newProfile').addEventListener('click',newProfile);$('#profileForm').addEventListener('submit',saveProfile);$('#deleteProfile').addEventListener('click',deleteProfile);$('#profileTemperature').addEventListener('input',()=>$('#profileTempValue').textContent=Number($('#profileTemperature').value).toFixed(1));
  $('#settingsForm').addEventListener('submit',saveSettingsForm);$('#settingTemperature').addEventListener('input',()=>$('#settingTemperatureValue').textContent=Number($('#settingTemperature').value).toFixed(1));
  $('#themeToggle').addEventListener('click',()=>setTheme((document.documentElement.dataset.theme||'dark')==='dark'?'light':'dark'));
  $('#openSidebar').addEventListener('click',()=>document.body.classList.add('sidebar-open'));$('#closeSidebar').addEventListener('click',()=>document.body.classList.remove('sidebar-open'));$('#scrim').addEventListener('click',()=>document.body.classList.remove('sidebar-open'));
  $('#authForm').addEventListener('submit',async e=>{e.preventDefault();sessionStorage.setItem('omni_access_token',$('#authToken').value);try{await api('/api/config');$('#authModal').hidden=true;$('#authToken').value='';await boot();toast('Session unlocked.','success')}catch(err){sessionStorage.removeItem('omni_access_token');toast('Token rejected or server unavailable.','error')}});
  document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();newChat()}if(e.key==='Escape')document.body.classList.remove('sidebar-open')});

  async function boot(){
    try{const auth=await api('/api/auth/status');if(auth.required&&!sessionStorage.getItem('omni_access_token')){authPrompt();return}await loadSettings();await Promise.all([loadConversations(),loadTools(),loadProfiles()]);await loadTasks();}
    catch(err){if(!/Authentication required/.test(err.message))toast(`OMNI initialization failed: ${err.message}`,'error')}
  }
  boot();
})();
