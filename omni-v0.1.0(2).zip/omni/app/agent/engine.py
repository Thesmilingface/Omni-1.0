"""Bounded, resumable, permission-aware task execution engine."""
from __future__ import annotations
import json
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse
from app.db import connection, get_settings, now_iso
from app.tools.registry import REGISTRY, ToolError, execute_tool

TERMINAL = {"COMPLETED", "FAILED", "CANCELLED", "PARTIALLY_COMPLETED"}
ALLOWED_STATES = {"RECEIVED", "ANALYZED", "PLANNED", "EXECUTING", "VERIFYING", "COMPLETED", "WAITING_FOR_INPUT", "WAITING_FOR_APPROVAL", "RETRYING", "FAILED", "CANCELLED", "PARTIALLY_COMPLETED"}


def _extract_expression(objective: str) -> str | None:
    patterns = [r"(?:calculate|compute|evaluate|what\s+is|how\s+much\s+is)\s+(.+)$"]
    for pattern in patterns:
        match = re.search(pattern, objective.strip(), flags=re.I)
        if match:
            expr = match.group(1).strip().rstrip("?.! ")
            expr = re.sub(r"\s+(?:and|then)\s+(?:save|write|create|store|explain|show|describe|give|tell)\b.*$", "", expr, flags=re.I)
            if len(expr) <= 256 and re.fullmatch(r"[\d\s.+*/()%\-^,a-zA-Z_]+", expr):
                return expr
    # A standalone arithmetic expression can be a useful objective too.
    stripped = objective.strip().rstrip("?.!")
    if re.fullmatch(r"[\d\s.+*/()%\-^]+", stripped) and any(c in stripped for c in "+*/^-()%"):
        return stripped
    return None


def _filename_from_objective(objective: str) -> str:
    patterns = [
        r"\b(?:named|called|as)\s+[`\'\"]?([A-Za-z0-9_./ -]+\.[A-Za-z0-9]{1,8})[`\'\"]?",
        r"\bfile(?:\s+at)?\s+[`\'\"]?([A-Za-z0-9_./-]+\.[A-Za-z0-9]{1,8})[`\'\"]?",
        r"\b(?:save|write|store)\s+(?:(?:the\s+)?(?:result|answer|output|report|note|file)\s+)?to\s+[`\'\"]?([A-Za-z0-9_./-]+\.[A-Za-z0-9]{1,8})[`\'\"]?",
    ]
    for pattern in patterns:
        m = re.search(pattern, objective, re.I)
        if m:
            candidate = m.group(1).strip().replace(" ", "-")
            if candidate and not candidate.startswith(("/", "\\")) and ".." not in candidate.split("/"):
                return candidate
    return f"omni-task-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.md"


def _write_content(objective: str, steps: list[dict[str, Any]]) -> str:
    explicit = re.search(r"(?:content|containing|with text)\s*[:=]\s*[`'\"]?(.*?)[`'\"]?\s*$", objective, re.I | re.S)
    if explicit:
        return explicit.group(1).strip()
    for step in reversed(steps):
        if step.get("status") == "completed" and step.get("tool") == "web_search":
            data = step.get("result", {})
            lines = ["# Research notes", "", f"Original objective: {objective}", "", "These notes contain snippets returned by the configured web-search provider; verify original sources before relying on them.", ""]
            for i, item in enumerate(data.get("results", []), start=1):
                lines += [f"## {i}. {item.get('title') or 'Untitled result'}", f"Source: {item.get('url', '')}", "", item.get("snippet", ""), ""]
            return "\n".join(lines).strip() + "\n"
        if step.get("status") == "completed" and step.get("tool") == "calculator":
            data = step.get("result", {})
            return f"# Calculation result\n\nObjective: {objective}\n\nExpression: `{data.get('expression', '')}`\n\nResult: **{data.get('formatted', data.get('value', ''))}**\n"
    # Do not pretend this content was researched or authored by an LLM.
    return (f"# Task draft\n\n"
            f"**Requested objective:** {objective}\n\n"
            "This file was created by OMNI's deterministic task runner. It is a structured starting draft, not independently researched or model-generated content.\n")


def plan_objective(objective: str) -> list[dict[str, Any]]:
    obj = objective.strip()
    lower = obj.lower()
    plan: list[dict[str, Any]] = []
    expression = _extract_expression(obj)
    if expression:
        plan.append({"id": str(uuid.uuid4()), "title": "Evaluate arithmetic", "tool": "calculator", "input": {"expression": expression}, "status": "pending"})
    urls = re.findall(r"https?://[^\s<>'\"]+", obj)
    if urls:
        url = urls[0].rstrip(".,);]")
        plan.append({"id": str(uuid.uuid4()), "title": "Retrieve URL content", "tool": "fetch_url", "input": {"url": url}, "status": "pending"})
    if re.search(r"\b(search|research|look up|find sources|find information)\b", lower):
        query_match = re.search(r"(?:search(?:\s+the\s+web)?\s+for|research|look\s+up|find\s+information\s+about)\s+(.+)$", obj, re.I)
        query = query_match.group(1).strip().rstrip("?.!") if query_match else obj
        query = re.sub(r"\s+(?:and\s+)?(?:save|write|create)\s+(?:a\s+)?(?:file|report|note).*?$", "", query, flags=re.I)
        plan.append({"id": str(uuid.uuid4()), "title": "Search configured web provider", "tool": "web_search", "input": {"query": query[:500], "max_results": 5}, "status": "pending"})
    if re.search(r"\b(list|show)\s+(?:my\s+)?(?:workspace\s+)?files\b|\blist\s+workspace\b", lower):
        plan.append({"id": str(uuid.uuid4()), "title": "List workspace files", "tool": "workspace_list", "input": {"path": "."}, "status": "pending"})
    read_match = re.search(r"\b(?:read|open)\s+(?:the\s+)?file\s+[`'\"]?([^`'\"\s]+)", obj, re.I)
    if read_match:
        plan.append({"id": str(uuid.uuid4()), "title": "Read workspace file", "tool": "workspace_read", "input": {"path": read_match.group(1)}, "status": "pending"})
    if re.search(r"\b(create|write|save|draft|generate|make|store)\b", lower) and (re.search(r"\b(file|note|report|document|readme|plan|draft)\b", lower) or re.search(r"\.(?:md|txt|json|csv|html|css|py|js|ts|yaml|yml)\b", lower)):
        plan.append({"id": str(uuid.uuid4()), "title": "Write requested file (approval required)", "tool": "workspace_write", "input": {"path": _filename_from_objective(obj), "content": ""}, "status": "pending", "content_from_prior_steps": True})
    if not plan:
        plan.append({"id": str(uuid.uuid4()), "title": "Analyze objective and prepare execution plan", "tool": None, "input": {}, "status": "pending", "description": "No enabled deterministic tool matched this objective. A language-model planner is not configured in the task engine yet."})
    return plan


def _update(task_id: str, **fields: Any) -> None:
    fields["updated_at"] = now_iso()
    sets = []
    vals: list[Any] = []
    for key, val in fields.items():
        if key in {"plan", "steps", "approved_steps"}:
            key = {"plan":"plan_json", "steps":"steps_json", "approved_steps":"approved_steps_json"}[key]
            val = json.dumps(val, ensure_ascii=False)
        elif key == "cancel_requested":
            val = int(bool(val))
        sets.append(f"{key}=?"); vals.append(val)
    vals.append(task_id)
    with connection() as conn:
        conn.execute(f"UPDATE tasks SET {', '.join(sets)} WHERE id=?", vals)


def get_task(task_id: str) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    if row is None: return None
    item = dict(row)
    item["plan"] = json.loads(item.pop("plan_json"))
    item["steps"] = json.loads(item.pop("steps_json"))
    item["approved_steps"] = json.loads(item.pop("approved_steps_json"))
    item["cancel_requested"] = bool(item["cancel_requested"])
    return item


def request_cancel(task_id: str) -> dict[str, Any] | None:
    task = get_task(task_id)
    if not task: return None
    if task["status"] in TERMINAL: return task
    if task["status"] in {"WAITING_FOR_APPROVAL", "WAITING_FOR_INPUT"}:
        steps = task["steps"]
        for step in steps:
            if step.get("status") == "waiting_for_approval":
                step["status"] = "cancelled"
                step["error"] = "Cancelled while awaiting approval."
        _update(task_id, cancel_requested=True, steps=steps, status="CANCELLED", result="Task cancelled while waiting for user input or approval.")
    else:
        _update(task_id, cancel_requested=True)
    return get_task(task_id)


def _log_tool(task_id: str, step: dict[str, Any], status: str, output: Any = None, error: str | None = None) -> None:
    with connection() as conn:
        conn.execute("INSERT INTO tool_runs(id,task_id,tool_name,status,input_json,output_json,error,created_at) VALUES(?,?,?,?,?,?,?,?)",
                     (str(uuid.uuid4()), task_id, step.get("tool") or "internal", status, json.dumps(step.get("input", {})), json.dumps(output if output is not None else {}, ensure_ascii=False), error, now_iso()))


def _verify(tool: str, result: dict[str, Any]) -> tuple[bool, str]:
    if tool == "calculator":
        return ("value" in result, "Calculator returned a numeric result." if "value" in result else "Calculator result missing.")
    if tool == "workspace_write":
        return (bool(result.get("verified")), "File was re-read and content matched." if result.get("verified") else "File verification failed.")
    if tool == "workspace_read":
        return ("content" in result, "Read operation returned file content." if "content" in result else "No file content returned.")
    if tool == "workspace_list":
        return ("items" in result, "Workspace directory listing returned." if "items" in result else "Directory listing missing.")
    if tool == "web_search":
        return (int(result.get("count", 0)) > 0, f"Search returned {result.get('count', 0)} result(s).")
    if tool == "fetch_url":
        return (int(result.get("status_code", 0)) < 400 and "text" in result, "HTTP response retrieved and content extracted." if result.get("status_code", 500) < 400 else "URL retrieval did not succeed.")
    return (False, "No verifier is registered for this tool.")


def recover_interrupted_tasks() -> list[str]:
    """Find non-terminal execution records after a process restart.

    Built-in steps resume from their persisted checkpoints. An interrupted untrusted/admin plugin
    step is not replayed automatically because it may already have changed external state.
    """
    with connection() as conn:
        ids = [row["id"] for row in conn.execute(
            "SELECT id FROM tasks WHERE status IN ('RECEIVED','ANALYZED','PLANNED','EXECUTING','VERIFYING','RETRYING') ORDER BY created_at"
        )]
    builtin = {"calculator", "workspace_list", "workspace_read", "workspace_write", "fetch_url", "web_search"}
    resumable: list[str] = []
    for task_id in ids:
        task = get_task(task_id)
        if not task:
            continue
        interrupted_plugin = next((step for step in task.get("steps", [])
            if step.get("tool") and step.get("tool") not in builtin and step.get("status") not in ("completed", "failed", "cancelled")), None)
        if interrupted_plugin:
            _update(task_id, status="PARTIALLY_COMPLETED", error=(
                f"Recovery stopped before replaying plugin step {interrupted_plugin.get('tool')!r}. "
                "Inspect possible external side effects before creating a new task."))
            continue
        resumable.append(task_id)
    return resumable


def run_task(task_id: str) -> None:
    settings = get_settings()
    task = get_task(task_id)
    if not task or task["status"] in TERMINAL: return
    # A profile's tool list is an additional allowlist; it can never grant tools disabled globally.
    profile_id = task.get("profile_id") or settings.get("default_profile", "omni-general")
    try:
        with connection() as conn:
            profile_row = conn.execute("SELECT tools_json FROM profiles WHERE id=?", (profile_id,)).fetchone()
        if profile_row is not None:
            profile_tools = set(json.loads(profile_row["tools_json"]))
            settings["enabled_tools"] = [name for name in settings.get("enabled_tools", []) if name in profile_tools]
    except (ValueError, TypeError, json.JSONDecodeError):
        settings["enabled_tools"] = []
    started = time.monotonic()
    try:
        if task["status"] == "RECEIVED":
            _update(task_id, status="ANALYZED")
            task = get_task(task_id); assert task
        if task["status"] == "ANALYZED" and not task["plan"]:
            plan = plan_objective(task["objective"])
            steps = [{**p, "attempts": 0, "verification": None, "result": None, "error": None} for p in plan]
            _update(task_id, plan=plan, steps=steps, status="PLANNED")
            task = get_task(task_id); assert task
        plan = task["plan"]
        steps = task["steps"]
        approved = set(task["approved_steps"])
        _update(task_id, status="EXECUTING")
        prior_results: list[dict[str, Any]] = [s for s in steps if s.get("status") == "completed" and (s.get("verification") or {}).get("passed")]
        for index, step in enumerate(steps):
            if step.get("status") == "completed":
                # A process may have stopped after persisting a result but before persisting its verifier.
                # Verify the saved result now rather than re-running the action.
                if step.get("tool") and not step.get("verification"):
                    _update(task_id, status="VERIFYING", steps=steps)
                    ok, message = _verify(str(step.get("tool")), step.get("result") or {})
                    step["verification"] = {"passed": ok, "message": message}
                    if not ok:
                        step["status"] = "failed"
                        step["error"] = "Recovery verification failed: " + message
                    else:
                        prior_results.append(step)
                    _update(task_id, steps=steps, status="EXECUTING")
                elif (step.get("verification") or {}).get("passed"):
                    if step not in prior_results: prior_results.append(step)
                continue
            latest = get_task(task_id)
            if not latest: return
            if latest["cancel_requested"]:
                step["status"] = "cancelled"
                _update(task_id, steps=steps, status="CANCELLED", result="Task cancelled by user.")
                return
            if time.monotonic() - started > float(settings.get("task_timeout_seconds", 90)):
                step["status"] = "failed"; step["error"] = "Task time budget exceeded."
                _update(task_id, steps=steps, status="PARTIALLY_COMPLETED" if prior_results else "FAILED", error=step["error"])
                return
            if step.get("tool") is None:
                step["status"] = "completed"
                step["result"] = {"message": step.get("description", "Planning completed."), "objective": task["objective"]}
                step["verification"] = {"passed": True, "message": "Objective and limitations recorded; no external action claimed."}
                prior_results.append(step)
                _log_tool(task_id, step, "completed", step["result"])
                _update(task_id, steps=steps)
                continue
            tool = str(step["tool"])
            spec = REGISTRY.get(tool)
            if not spec:
                step["status"] = "failed"; step["error"] = f"Tool {tool!r} is not registered."; _log_tool(task_id, step, "failed", error=step["error"]); continue
            if tool not in set(settings.get("enabled_tools", [])):
                step["status"] = "failed"; step["error"] = f"Tool {tool!r} is disabled in Settings."; _log_tool(task_id, step, "failed", error=step["error"]); _update(task_id, steps=steps); continue
            if spec.requires_approval and step["id"] not in approved:
                step["status"] = "waiting_for_approval"
                _update(task_id, steps=steps, status="WAITING_FOR_APPROVAL")
                _log_tool(task_id, step, "waiting_for_approval")
                return
            args = dict(step.get("input", {}))
            if step.get("content_from_prior_steps"):
                prerequisite_steps = steps[:index]
                unfinished = [prev for prev in prerequisite_steps if prev.get("tool") and (prev.get("status") != "completed" or not (prev.get("verification") or {}).get("passed"))]
                if unfinished:
                    step["status"] = "failed"
                    step["error"] = "This file step depends on earlier tool results that did not pass verification."
                    _log_tool(task_id, step, "failed", error=step["error"])
                    _update(task_id, steps=steps)
                    continue
                args["content"] = _write_content(task["objective"], prior_results)
                step["input"] = args
            max_retries = max(0, min(3, int(settings.get("task_retry_limit", 2))))
            attempt = 0
            while True:
                step["attempts"] = attempt + 1
                try:
                    result = execute_tool(tool, args, settings, approved=step["id"] in approved)
                    step["result"] = result; step["status"] = "completed"
                    _log_tool(task_id, step, "completed", result)
                    break
                except ToolError as exc:
                    step["status"] = "failed"; step["error"] = str(exc); _log_tool(task_id, step, "failed", error=str(exc)); break
                except Exception as exc:
                    if attempt < max_retries:
                        attempt += 1; step["status"] = "retrying"; _update(task_id, steps=steps, status="RETRYING")
                        continue
                    step["status"] = "failed"; step["error"] = f"Execution failed after {attempt + 1} attempt(s): {str(exc)[:300]}"; _log_tool(task_id, step, "failed", error=step["error"]); break
            if step.get("status") == "completed":
                _update(task_id, status="VERIFYING", steps=steps)
                ok, message = _verify(tool, step.get("result") or {})
                step["verification"] = {"passed": ok, "message": message}
                if ok: prior_results.append(step)
                else: step["status"] = "failed"; step["error"] = "Verification failed: " + message
            _update(task_id, steps=steps, status="EXECUTING")
        succeeded = [s for s in steps if s.get("status") == "completed" and (s.get("verification") or {}).get("passed")]
        failed = [s for s in steps if s.get("status") in ("failed", "cancelled")]
        if failed:
            status = "PARTIALLY_COMPLETED" if succeeded else "FAILED"
            result_text = "Some task steps completed, but one or more steps failed. Review the execution trace for the exact blocker."
            error = "; ".join(s.get("error", "cancelled") for s in failed)
        else:
            status = "COMPLETED" if succeeded else "PARTIALLY_COMPLETED"
            result_text = "Task execution and registered verification checks completed." if succeeded and all((s.get("verification") or {}).get("passed") for s in steps) else "The objective was analyzed and a plan was created, but no executable tool matched it. No external action is claimed."
            error = None
        _update(task_id, steps=steps, status=status, result=result_text, error=error)
    except Exception as exc:
        task = get_task(task_id)
        if task:
            _update(task_id, status="PARTIALLY_COMPLETED" if any(s.get("status") == "completed" for s in task.get("steps", [])) else "FAILED", error=f"Internal task engine error: {str(exc)[:300]}")
