"""Environment and persisted configuration helpers for OMNI."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "provider": "mock",
    "base_url": "http://127.0.0.1:11434/v1",
    "model": "qwen2.5:3b",
    "temperature": 0.3,
    "max_tokens": 1200,
    "system_instructions": "You are OMNI, a transparent, solution-oriented assistant. Verify claims and never claim an action succeeded unless it did.",
    "network_enabled": False,
    "enabled_tools": ["calculator", "workspace_list", "workspace_read", "workspace_write", "fetch_url", "web_search"],
    "task_retry_limit": 2,
    "task_timeout_seconds": 90,
    "default_profile": "omni-general",
    "theme": "dark",
}


def data_dir() -> Path:
    return Path(os.environ.get("OMNI_DATA_DIR", str(Path.cwd() / "data"))).expanduser().resolve()


def database_path() -> Path:
    raw = os.environ.get("OMNI_DB_PATH")
    return Path(raw).expanduser().resolve() if raw else data_dir() / "omni.sqlite3"


def workspace_dir() -> Path:
    raw = os.environ.get("OMNI_WORKSPACE_DIR")
    path = Path(raw).expanduser().resolve() if raw else Path.cwd() / "workspace"
    path.mkdir(parents=True, exist_ok=True)
    return path


def access_token() -> str | None:
    token = os.environ.get("OMNI_ACCESS_TOKEN", "").strip()
    return token or None


def provider_key() -> str | None:
    key = os.environ.get("OMNI_API_KEY") or os.environ.get("OPENAI_API_KEY")
    return key.strip() if key and key.strip() else None
