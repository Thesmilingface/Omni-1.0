"""Deterministic offline demo provider; never represented as a real language model."""
from __future__ import annotations
import asyncio
from typing import Any, AsyncIterator


def _answer(messages: list[dict[str, str]], config: dict[str, Any]) -> str:
    user_text = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    system = next((m.get("content", "") for m in messages if m.get("role") == "system"), "")
    text = user_text.strip()
    lowered = text.lower()
    if not text:
        body = "Send an objective or question to begin."
    elif any(greet in lowered for greet in ("hello", "hi omni", "hey omni")):
        body = "Hello. OMNI is running in **offline demo mode**. Connect an OpenAI-compatible model endpoint in Settings to enable real model-generated conversations."
    elif "capabilit" in lowered or "what can you do" in lowered:
        body = "I can persist conversations, run a bounded task workflow, evaluate arithmetic safely, manage files inside the OMNI workspace, and use optional network tools when enabled. This demo provider does not perform general-purpose language-model reasoning. Connect a model in Settings for that."
    elif any(word in lowered for word in ("calculate", "compute", "evaluate", "what is ")):
        body = "I can evaluate arithmetic through the **Calculator** tool. Open **Tools**, enter an arithmetic expression, and run it; expressions are parsed with a restricted syntax tree rather than executed as Python."
    else:
        body = ("**Offline demo response**\n\n"
                "OMNI saved your message, but the demo provider is a deterministic local stub, not an LLM. "
                "For a substantive answer, open **Settings → Model provider**, select **OpenAI-compatible**, and set your local Ollama or other compatible endpoint. "
                "No network request was made for this response.\n\n"
                f"**Received objective:** {text[:900]}")
    if system and "Be direct" in system:
        return body
    return body

async def generate_mock(messages: list[dict[str, str]], config: dict[str, Any]) -> str:
    return _answer(messages, config)

async def stream_mock(messages: list[dict[str, str]], config: dict[str, Any]) -> AsyncIterator[str]:
    answer = _answer(messages, config)
    # Chunking is only transport/UI streaming; the demo answer itself is generated as one deterministic string.
    for start in range(0, len(answer), 24):
        await asyncio.sleep(0.006)
        yield answer[start:start + 24]
