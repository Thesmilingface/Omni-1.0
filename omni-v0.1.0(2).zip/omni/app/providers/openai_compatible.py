"""Adapter for OpenAI-compatible APIs, including Ollama's /v1 endpoints."""
from __future__ import annotations
import json
from typing import Any, AsyncIterator
import httpx
from app.config import provider_key
from app.providers.base import ProviderError


def _url(config: dict[str, Any], suffix: str) -> str:
    base = str(config.get("base_url", "http://127.0.0.1:11434/v1")).strip().rstrip("/")
    if not base.startswith(("http://", "https://")):
        raise ProviderError("The model endpoint must use http:// or https://")
    return f"{base}/{suffix.lstrip('/')}"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    key = provider_key()
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return headers


def _payload(messages: list[dict[str, str]], config: dict[str, Any], stream: bool = False) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": config.get("model") or "qwen2.5:3b",
        "messages": messages,
        "temperature": float(config.get("temperature", 0.3)),
        "max_tokens": int(config.get("max_tokens", 1200)),
        "stream": stream,
    }
    return payload

async def generate_openai_compatible(messages: list[dict[str, str]], config: dict[str, Any]) -> str:
    try:
        async with httpx.AsyncClient(timeout=float(config.get("model_timeout_seconds", 120))) as client:
            response = await client.post(_url(config, "chat/completions"), headers=_headers(), json=_payload(messages, config))
            response.raise_for_status()
            data = response.json()
            return str(data["choices"][0]["message"]["content"] or "")
    except ProviderError:
        raise
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError) as exc:
        detail = str(exc)
        if isinstance(exc, httpx.HTTPStatusError):
            detail = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
        raise ProviderError(f"Model request failed: {detail}") from exc

async def stream_openai_compatible(messages: list[dict[str, str]], config: dict[str, Any]) -> AsyncIterator[str]:
    try:
        async with httpx.AsyncClient(timeout=float(config.get("model_timeout_seconds", 120))) as client:
            async with client.stream("POST", _url(config, "chat/completions"), headers=_headers(), json=_payload(messages, config, True)) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data_text = line[5:].strip()
                    if data_text == "[DONE]":
                        break
                    try:
                        data = json.loads(data_text)
                        delta = data.get("choices", [{}])[0].get("delta", {}).get("content")
                        if delta:
                            yield str(delta)
                    except (json.JSONDecodeError, IndexError, AttributeError, TypeError):
                        continue
    except ProviderError:
        raise
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError) as exc:
        detail = str(exc)
        if isinstance(exc, httpx.HTTPStatusError):
            detail = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
        raise ProviderError(f"Streaming model request failed: {detail}") from exc

async def list_models(config: dict[str, Any]) -> tuple[bool, list[dict[str, Any]], str | None]:
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            response = await client.get(_url(config, "models"), headers=_headers())
            response.raise_for_status()
            data = response.json()
            models = [{"id": str(item.get("id", "")), "object": item.get("object", "model")} for item in data.get("data", []) if item.get("id")]
            return True, models, None
    except Exception as exc:
        return False, [], f"Model list unavailable: {str(exc)[:240]}"
