from __future__ import annotations
from typing import Any, AsyncIterator

class ProviderError(RuntimeError):
    pass

async def generate(messages: list[dict[str, str]], config: dict[str, Any]) -> str:
    from app.providers.mock import generate_mock
    from app.providers.openai_compatible import generate_openai_compatible
    if config.get("provider", "mock") == "mock":
        return await generate_mock(messages, config)
    if config.get("provider") == "openai_compatible":
        return await generate_openai_compatible(messages, config)
    raise ProviderError(f"Unsupported provider mode: {config.get('provider')!r}")

async def stream(messages: list[dict[str, str]], config: dict[str, Any]) -> AsyncIterator[str]:
    from app.providers.mock import stream_mock
    from app.providers.openai_compatible import stream_openai_compatible
    if config.get("provider", "mock") == "mock":
        async for token in stream_mock(messages, config):
            yield token
        return
    if config.get("provider") == "openai_compatible":
        async for token in stream_openai_compatible(messages, config):
            yield token
        return
    raise ProviderError(f"Unsupported provider mode: {config.get('provider')!r}")
