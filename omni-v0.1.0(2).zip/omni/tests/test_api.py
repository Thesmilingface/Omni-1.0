import os
import pytest
from fastapi.testclient import TestClient

@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("OMNI_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("OMNI_WORKSPACE_DIR", str(tmp_path / "workspace"))
    monkeypatch.delenv("OMNI_ACCESS_TOKEN", raising=False)
    monkeypatch.delenv("OMNI_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OMNI_TAVILY_API_KEY", raising=False)
    from app.main import app
    with TestClient(app) as test_client:
        yield test_client


def test_health_reports_demo_mode(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["service"] == "OMNI"
    assert response.json()["demo_mode"] is True


def test_chat_persists_conversation_and_is_honest_about_mock(client):
    response = client.post("/api/chat", json={"message": "Hello OMNI"})
    assert response.status_code == 200
    payload = response.json()
    assert payload["demo_mode"] is True
    assert "offline demo mode" in payload["message"]["content"].lower()
    detail = client.get(f"/api/conversations/{payload['conversation_id']}")
    assert detail.status_code == 200
    assert [m["role"] for m in detail.json()["messages"]] == ["user", "assistant"]


def test_calculator_tool_and_restricted_syntax(client):
    result = client.post("/api/tools/calculator/execute", json={"input": {"expression": "(12 + 3) * 4"}})
    assert result.status_code == 200
    assert result.json()["output"]["value"] == 60
    rejected = client.post("/api/tools/calculator/execute", json={"input": {"expression": "__import__('os').system('whoami')"}})
    assert rejected.status_code == 400


def test_workspace_write_requires_approval_and_is_verified(client, tmp_path):
    body = {"input": {"path": "notes/demo.md", "content": "OMNI verified write"}}
    denied = client.post("/api/tools/workspace_write/execute", json=body)
    assert denied.status_code == 409
    result = client.post("/api/tools/workspace_write/execute", json={**body, "approved": True})
    assert result.status_code == 200
    assert result.json()["output"]["verified"] is True
    assert (tmp_path / "workspace" / "notes" / "demo.md").read_text() == "OMNI verified write"


def test_workspace_path_traversal_is_blocked(client, tmp_path):
    outside = tmp_path / "secret.txt"
    outside.write_text("not in workspace")
    response = client.post("/api/tools/workspace_read/execute", json={"input": {"path": "../secret.txt"}})
    assert response.status_code == 400
    assert "escapes" in response.json()["detail"].lower()


def test_config_rejects_unknown_tools_and_invalid_endpoint(client):
    bad_tool = client.put("/api/config", json={"enabled_tools": ["run_shell"]})
    assert bad_tool.status_code == 422
    bad_url = client.put("/api/config", json={"base_url": "file:///etc/passwd"})
    assert bad_url.status_code == 422


def test_task_engine_completes_and_verifies_arithmetic(client):
    response = client.post("/api/tasks", json={"objective": "Calculate 13 * 7"})
    assert response.status_code == 202
    task = client.get(f"/api/tasks/{response.json()['id']}").json()
    assert task["status"] == "COMPLETED"
    assert any(step.get("result", {}).get("value") == 91 for step in task["steps"])
    assert all(step.get("verification", {}).get("passed") for step in task["steps"])


def test_task_waits_for_approval_before_file_write_then_completes(client, tmp_path):
    response = client.post("/api/tasks", json={"objective": "Create a file named result.md with content: approved result"})
    task_id = response.json()["id"]
    task = client.get(f"/api/tasks/{task_id}").json()
    assert task["status"] == "WAITING_FOR_APPROVAL"
    assert not (tmp_path / "workspace" / "result.md").exists()
    resumed = client.post(f"/api/tasks/{task_id}/approve")
    assert resumed.status_code == 200
    task = client.get(f"/api/tasks/{task_id}").json()
    assert task["status"] == "COMPLETED"
    assert (tmp_path / "workspace" / "result.md").read_text() == "approved result"


def test_memory_create_search_and_delete(client):
    created = client.post("/api/memories", json={"content": "Prefer concise project updates", "category": "preference", "scope": "global"})
    assert created.status_code == 201
    memory_id = created.json()["id"]
    found = client.get("/api/memories", params={"q": "concise"})
    assert len(found.json()) == 1
    assert client.delete(f"/api/memories/{memory_id}").json()["deleted"] is True
    assert client.get("/api/memories", params={"q": "concise"}).json() == []


def test_builtin_profiles_are_seeded_and_cannot_be_deleted(client):
    profiles = client.get("/api/profiles").json()
    assert {p["id"] for p in profiles} >= {"omni-general", "omni-research", "omni-developer"}
    response = client.delete("/api/profiles/omni-general")
    assert response.status_code == 409


def test_streaming_chat_emits_deltas_and_persists_assistant(client):
    response = client.post("/api/chat/stream", json={"message": "Hello OMNI"})
    assert response.status_code == 200
    body = response.text
    assert '"type": "delta"' in body
    assert '"type": "done"' in body
    event_line = next(line for line in body.splitlines() if line.startswith("data: ") and '"type": "done"' in line)
    import json
    done = json.loads(event_line[6:])
    detail = client.get(f"/api/conversations/{done['conversation_id']}").json()
    assert [m["role"] for m in detail["messages"]] == ["user", "assistant"]


def test_task_profile_is_an_additional_tool_allowlist(client):
    profile = client.post("/api/profiles", json={
        "name": "No tools", "description": "Testing least privilege", "instructions": "",
        "provider": "", "model": "", "temperature": 0.3, "memory_scope": "global", "tools": []
    })
    assert profile.status_code == 201
    task = client.post("/api/tasks", json={"objective": "Calculate 2 + 2", "profile_id": profile.json()["id"]})
    data = client.get(f"/api/tasks/{task.json()['id']}").json()
    assert data["status"] == "FAILED"
    assert "disabled in settings" in data["error"].lower()


def test_profile_memory_scope_retrieves_global_and_matching_notes_only(client, monkeypatch):
    import app.main as main_module
    global_mem = client.post("/api/memories", json={"content": "GLOBAL_CONTEXT_SENTINEL", "scope": "global", "category": "note"})
    project_mem = client.post("/api/memories", json={"content": "PROJECT_A_CONTEXT_SENTINEL", "scope": "project-a", "category": "project"})
    other_mem = client.post("/api/memories", json={"content": "PROJECT_B_SHOULD_NOT_APPEAR", "scope": "project-b", "category": "project"})
    profile = client.post("/api/profiles", json={
        "name": "Project A", "description": "Scoped memory profile", "instructions": "",
        "provider": "mock", "model": "", "temperature": 0.2, "memory_scope": "project-a", "tools": ["calculator"]
    })
    captured = {}
    async def fake_generate(messages, config):
        captured["messages"] = messages
        return "captured"
    monkeypatch.setattr(main_module, "generate", fake_generate)
    result = client.post("/api/chat", json={"message": "Test scope", "profile_id": profile.json()["id"]})
    assert result.status_code == 200
    system = captured["messages"][0]["content"]
    assert "GLOBAL_CONTEXT_SENTINEL" in system
    assert "PROJECT_A_CONTEXT_SENTINEL" in system
    assert "PROJECT_B_SHOULD_NOT_APPEAR" not in system


def test_file_write_after_calculation_is_a_multistep_verified_task(client, tmp_path):
    response = client.post("/api/tasks", json={"objective": "Calculate 12 * 4 and save the result to result.md"})
    task_id = response.json()["id"]
    pending = client.get(f"/api/tasks/{task_id}").json()
    assert pending["status"] == "WAITING_FOR_APPROVAL"
    assert pending["steps"][0]["result"]["value"] == 48
    assert pending["steps"][1]["input"]["path"] == "result.md"
    client.post(f"/api/tasks/{task_id}/approve")
    completed = client.get(f"/api/tasks/{task_id}").json()
    assert completed["status"] == "COMPLETED"
    assert len(completed["steps"]) == 2
    assert all(step["verification"]["passed"] for step in completed["steps"])
    assert "48" in (tmp_path / "workspace" / "result.md").read_text()


def test_bearer_auth_protects_api_when_configured(tmp_path, monkeypatch):
    monkeypatch.setenv("OMNI_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("OMNI_WORKSPACE_DIR", str(tmp_path / "workspace"))
    monkeypatch.setenv("OMNI_ACCESS_TOKEN", "unit-test-secret")
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as secured:
        assert secured.get("/api/health").status_code == 200
        assert secured.get("/api/config").status_code == 401
        response = secured.get("/api/config", headers={"Authorization": "Bearer unit-test-secret"})
        assert response.status_code == 200


def test_cancel_while_waiting_for_approval_becomes_terminal(client):
    response = client.post("/api/tasks", json={"objective": "Create a file named cancel.md with content: do not write"})
    task_id = response.json()["id"]
    assert client.get(f"/api/tasks/{task_id}").json()["status"] == "WAITING_FOR_APPROVAL"
    cancelled = client.post(f"/api/tasks/{task_id}/cancel")
    assert cancelled.status_code == 200
    assert cancelled.json()["status"] == "CANCELLED"
    assert "CANCELLED" == client.get(f"/api/tasks/{task_id}").json()["status"]


def test_custom_profile_memory_scope_is_returned_and_editable(client):
    profile = client.post("/api/profiles", json={
        "name": "Scoped profile", "description": "", "instructions": "",
        "provider": "", "model": "", "temperature": 0.4, "memory_scope": "my-project", "tools": ["calculator"]
    })
    assert profile.status_code == 201
    assert profile.json()["memory_scope"] == "my-project"
    update = client.put(f"/api/profiles/{profile.json()['id']}", json={
        "name": "Scoped profile", "description": "updated", "instructions": "test",
        "provider": "", "model": "", "temperature": 0.6, "memory_scope": "global", "tools": ["calculator"]
    })
    assert update.status_code == 200
    assert update.json()["memory_scope"] == "global"


def test_recovery_resumes_completed_result_checkpoint_without_reexecuting(client):
    import json
    import uuid
    from app import db
    from app.agent.engine import recover_interrupted_tasks, run_task, get_task
    now = db.now_iso()
    task_id = str(uuid.uuid4())
    step_id = str(uuid.uuid4())
    step = {
        "id": step_id, "title": "Evaluate arithmetic", "tool": "calculator",
        "input": {"expression": "2 + 2"}, "status": "completed", "attempts": 1,
        "result": {"expression": "2 + 2", "value": 4, "formatted": "4"},
        "verification": None, "error": None,
    }
    plan = [{k: step[k] for k in ("id", "title", "tool", "input", "status")}]
    with db.connection() as conn:
        conn.execute("INSERT INTO tasks(id,objective,profile_id,status,plan_json,steps_json,approved_steps_json,result,error,cancel_requested,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                     (task_id, "Calculate 2 + 2", "omni-general", "EXECUTING", json.dumps(plan), json.dumps([step]), "[]", None, None, 0, now, now))
    assert task_id in recover_interrupted_tasks()
    run_task(task_id)
    resumed = get_task(task_id)
    assert resumed["status"] == "COMPLETED"
    assert resumed["steps"][0]["verification"]["passed"] is True
    assert resumed["steps"][0]["attempts"] == 1
