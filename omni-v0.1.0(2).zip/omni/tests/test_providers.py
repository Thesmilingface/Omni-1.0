import asyncio
import json
import httpx
from app.providers import openai_compatible


def _install_mock_transport(monkeypatch, handler):
    original_client = httpx.AsyncClient
    transport = httpx.MockTransport(handler)
    def factory(*args, **kwargs):
        return original_client(transport=transport, timeout=kwargs.get("timeout", 10.0))
    monkeypatch.setattr(openai_compatible.httpx, "AsyncClient", factory)


def test_openai_compatible_adapter_posts_configured_model(monkeypatch):
    monkeypatch.delenv("OMNI_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    seen = {}
    def handler(request):
        seen["url"] = str(request.url)
        seen["body"] = json.loads(request.content)
        return httpx.Response(200, json={"choices": [{"message": {"content": "A real adapter response"}}]})
    _install_mock_transport(monkeypatch, handler)
    config = {"provider": "openai_compatible", "base_url": "http://model.test/v1", "model": "example-model", "temperature": 0.2, "max_tokens": 222}
    result = asyncio.run(openai_compatible.generate_openai_compatible([{"role": "user", "content": "Hi"}], config))
    assert result == "A real adapter response"
    assert seen["url"] == "http://model.test/v1/chat/completions"
    assert seen["body"]["model"] == "example-model"
    assert seen["body"]["max_tokens"] == 222
    assert seen["body"]["stream"] is False


def test_openai_compatible_adapter_parses_native_sse_deltas(monkeypatch):
    monkeypatch.delenv("OMNI_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    content = (
        'data: {"choices":[{"delta":{"content":"Hello"}}]}\n\n'
        'data: {"choices":[{"delta":{"content":" world"}}]}\n\n'
        'data: [DONE]\n\n'
    )
    def handler(request):
        assert json.loads(request.content)["stream"] is True
        return httpx.Response(200, headers={"content-type":"text/event-stream"}, content=content)
    _install_mock_transport(monkeypatch, handler)
    config = {"provider": "openai_compatible", "base_url": "http://model.test/v1", "model": "example-model"}
    async def collect():
        result = []
        async for delta in openai_compatible.stream_openai_compatible([{"role":"user","content":"Hi"}], config):
            result.append(delta)
        return result
    assert asyncio.run(collect()) == ["Hello", " world"]
