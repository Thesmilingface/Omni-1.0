import pytest
from app.tools.registry import ToolError, execute_tool


def test_calculator_supports_safe_functions():
    settings = {"enabled_tools": ["calculator"], "network_enabled": False}
    assert execute_tool("calculator", {"expression": "sqrt(81) + abs(-2)"}, settings)["value"] == 11


def test_calculator_rejects_names_and_imports():
    settings = {"enabled_tools": ["calculator"], "network_enabled": False}
    with pytest.raises(ToolError):
        execute_tool("calculator", {"expression": "open('/tmp/a', 'w')"}, settings)


def test_tool_allowlist_is_enforced():
    with pytest.raises(ToolError, match="disabled"):
        execute_tool("calculator", {"expression": "2 + 2"}, {"enabled_tools": [], "network_enabled": False})


def test_network_tools_disabled_by_default():
    with pytest.raises(ToolError, match="disabled"):
        execute_tool("fetch_url", {"url": "https://example.com"}, {"enabled_tools": ["fetch_url"], "network_enabled": False})


def test_url_fetch_blocks_private_address_even_when_network_is_enabled():
    settings = {"enabled_tools": ["fetch_url"], "network_enabled": True}
    with pytest.raises(ToolError, match="blocked"):
        execute_tool("fetch_url", {"url": "http://127.0.0.1/admin"}, settings)
