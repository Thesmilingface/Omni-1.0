from app.tools.plugins import load_plugins
from app.tools.registry import REGISTRY, execute_tool


def test_python_plugin_loader_is_disabled_by_default(monkeypatch, tmp_path):
    monkeypatch.setenv("OMNI_PLUGIN_DIR", str(tmp_path))
    monkeypatch.setenv("OMNI_TRUST_PYTHON_PLUGINS", "false")
    (tmp_path / "safe_echo.py").write_text('PLUGIN = {"name":"test_echo", "description":"Echo input", "input_schema":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"],"additionalProperties":False}, "permissions":[], "timeout_seconds":2, "execute": lambda args, settings: {"echo": args["text"]}}')
    status = load_plugins()
    assert status[0]["enabled"] is False
    assert "test_echo" not in REGISTRY


def test_admin_trusted_plugin_registers_and_runs(monkeypatch, tmp_path):
    monkeypatch.setenv("OMNI_PLUGIN_DIR", str(tmp_path))
    monkeypatch.setenv("OMNI_TRUST_PYTHON_PLUGINS", "true")
    (tmp_path / "safe_echo.py").write_text('PLUGIN = {"name":"test_echo", "description":"Echo input", "input_schema":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"],"additionalProperties":False}, "permissions":[], "timeout_seconds":2, "execute": lambda args, settings: {"echo": args["text"]}}')
    status = load_plugins()
    assert any(item.get("name") == "test_echo" and item.get("loaded") for item in status)
    result = execute_tool("test_echo", {"text": "works"}, {"enabled_tools": ["test_echo"]})
    assert result == {"echo": "works"}
    monkeypatch.setenv("OMNI_TRUST_PYTHON_PLUGINS", "false")
    load_plugins()
    assert "test_echo" not in REGISTRY
