# Contributor Covenant Code of Conduct

## Our pledge

We as contributors and maintainers pledge to make participation in our community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, caste, color, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

## Our standards

Examples of behavior that contributes to a positive environment include demonstrating empathy, using welcoming language, respecting differing viewpoints, accepting constructive criticism, focusing on what is best for the community, and showing care toward other community members.

Examples of unacceptable behavior include sexualized comments or advances, trolling, insulting or derogatory comments, public or private harassment, publishing others' private information without permission, and other conduct that could reasonably be considered inappropriate in a professional setting.

## Responsibilities and enforcement

Maintainers are responsible for clarifying and enforcing standards and may remove, edit, or reject contributions that do not align with this Code of Conduct. They may temporarily or permanently exclude contributors for behavior they deem inappropriate, threatening, offensive, or harmful.

Report incidents privately to the repository maintainers. Maintainers should respond in a fair and timely manner. This Code of Conduct is adapted from the Contributor Covenant, version 2.1; see https://www.contributor-covenant.org/version/2/1/code_of_conduct.html.
