# OMNI v0.1.0 — Implementation Report

**Report date:** 2026-10-16  
**Release scope:** Functional foundation / early prototype  
**Repository state:** Source files in this project directory; local runtime data is excluded from the release archive.

## 1. What was implemented

### Functional foundation
- FastAPI service with typed request models and an auto-generated OpenAPI document.
- SQLite persistence for settings, conversations/messages, tasks, tool runs, profiles, memories, and projects, including additive schema migrations.
- Dependency-free static browser UI served by FastAPI. It includes responsive chat, streamed assistant output, conversation history, agent task status, approvals/cancellation, tools, profiles, model settings, project management, memory CRUD, and light/dark themes.
- Deterministic offline demo provider. The UI and API identify demo mode; it is not represented as an actual language model.
- OpenAI-compatible chat-completions adapter with non-streaming and Server-Sent Events streaming support, plus a configurable `/models` probe.
- Six seeded profiles (General, Research, Developer, Analyst, Creative, Automation). Profile instructions, model/provider overrides, tool allowlists, and memory scopes are persisted.

### Tools and agent tasks
- Tool registry with declared schemas/capability information, an AST-restricted calculator, and workspace-scoped list/read/write operations.
- Explicit approval before agent-driven file writes; post-write verification is recorded.
- Optional public HTTP(S) text retrieval and Tavily web search adapter. Network tools are disabled by default and enforce basic private/reserved-address and redirect checks; this is defense in depth, not a complete network sandbox.
- Persistent task lifecycle and task/step checkpoints; bounded retries and time budgets; task progress reporting; cancellation; explicit approval wait/resume; partial-completion reporting; startup recovery for built-in tool steps.
- Optional Python plugin contract and loader, disabled by default. Plugins must be trusted administrative code: execution is in-process and is not sandboxed.
- Optional single-instance Bearer-token gate for API use, plus audit records for tool invocations.

### Release and maintenance files
- MIT license for original project code; dependency/model licenses are separate.
- README, architecture notes, API guide, plugin developer guide, security notes, third-party notices, contribution guide, code of conduct, changelog, sample environment, Docker/Compose scaffolding, and a GitHub Actions test workflow.

## 2. Verification performed

The checks below were actually run in the provided development environment on 2026-10-16:

| Check | Result |
|---|---|
| `python3 -m compileall -q app run.py` | PASS |
| `node --check app/static/app.js` | PASS |
| `pytest -q` | PASS — 27 tests passed |
| Live local-server HTTP smoke test | PASS — health API, root UI, static JavaScript, and OpenAPI endpoints returned successful responses |

The tests cover API persistence and permission handling, tool input/scope validation, plugin loading contracts, provider payload/stream parsing, task approval and multi-step execution, and error paths. The compatible model adapter tests use a mocked HTTP transport; they do not demonstrate a live model server connection.

## 3. Available now

- Local browser UI and FastAPI API.
- Offline demo mode for application evaluation without a model key.
- Real chat through an independently installed OpenAI-compatible inference endpoint once configured.
- SQLite-backed conversation/profile/task/memory/project persistence.
- Restricted arithmetic and local workspace file operations.
- Optional configured URL fetch and Tavily search, with network permission enabled deliberately.
- Tool audit trail and approval boundary for file writes.
- A small, deterministic task runner that reports its outcome and does not claim unsupported requests succeeded.

## 4. Not yet implemented or verified

This release is **not** the full platform in the master specification. In particular:

- The task planner is heuristic and rule-based, not a general LLM-driven autonomous planner. Chat itself does not autonomously select tools.
- No live external model or search provider was available to validate with real credentials during these checks.
- React/Vite is not used yet; the UI is static HTML/CSS/JavaScript to reduce setup and browser network dependencies.
- No bundled Hugging Face Transformers or llama.cpp runtime, vision/audio/video/image generation, general browser/desktop automation, arbitrary shell execution, Git automation, calendar/email senders, PostgreSQL, vector database, semantic memory retrieval, scheduled workflows, or multi-user identity isolation.
- The bearer token is single-instance authentication, not a multi-user authorization model.
- Python plugins run in-process and are not sandboxed. Do not enable unreviewed plugins.
- Docker and Compose configuration files were added but were not executed in this environment; container behavior therefore remains unverified.
- Public-URL filtering and network controls provide useful guardrails, not a complete defense against all SSRF, DNS-rebinding, or infrastructure-level risks.

## 5. Exact next development step

The next engineering milestone should be **LLM-directed but permission-gated tool orchestration**: define a strict tool-call response schema for compatible model adapters, run model-proposed actions only through the existing allowlisted registry, validate each proposed call against the active profile and global permissions, require approval for state-changing operations, persist each proposal/result, and test prompt-injection and malformed-tool-call cases with mock providers before enabling it for live models. In parallel, add a CI integration test against an explicitly configured local inference endpoint; avoid describing that connection as verified until such a test actually runs.

## 6. Local run

Requirements: Python 3.11+.

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run.py
```

Open `http://127.0.0.1:8000`. Start with the labeled demo provider or configure an OpenAI-compatible endpoint in Settings. See `README.md` and `docs/SECURITY.md` before enabling network tools, remote binding, or trusted Python plugins.
